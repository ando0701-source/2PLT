@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore-finalization.ps1"
if errorlevel 1 (
  echo.
  echo [STOP] Recovery not completed. Original files were not intentionally deleted.
) else (
  echo.
  echo [DONE] Recovery completed.
)
pause
