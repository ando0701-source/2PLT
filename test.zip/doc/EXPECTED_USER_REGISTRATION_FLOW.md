# Expected analysis target: user registration

Use this only to evaluate whether Copilot can navigate from the index to the real source. It is not part of the instructions Copilot must blindly trust.

Suggested test request:

> ユーザー登録 `/users` の処理を、HTTP入口からDBのINSERT文まで追跡してください。索引を探索補助に使い、最終的な根拠は実ソースにしてください。ファイルは変更しないでください。

Expected evidence chain:

1. `src/main/java/io/spring/api/UsersApi.java`
   - `UsersApi#createUser`
   - calls `UserService#createUser`
2. `src/main/java/io/spring/application/user/UserService.java`
   - constructs `User`
   - calls `UserRepository#save`
3. `src/main/java/io/spring/core/user/UserRepository.java`
   - declares repository interface
4. `src/main/java/io/spring/infrastructure/repository/MyBatisUserRepository.java`
   - implements `UserRepository`
   - `save` delegates to `UserMapper#insert` for a new user
5. `src/main/java/io/spring/infrastructure/mybatis/mapper/UserMapper.java`
   - declares MyBatis mapper method `insert`
6. `src/main/resources/mapper/UserMapper.xml`
   - namespace is `io.spring.infrastructure.mybatis.mapper.UserMapper`
   - `<insert id="insert">` performs `insert into users (...)`

A good analysis should cross API -> application -> core interface -> infrastructure implementation -> Java mapper -> XML SQL rather than stopping at `UserRepository` or `UserMapper`.
