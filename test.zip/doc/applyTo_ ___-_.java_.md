---
applyTo: "**/*.java"
---

# Java Source Analysis Instructions

Javaソースコードを解析するときは、必要に応じて以下の構造を確認すること。

- package
- import
- annotation
- class
- interface
- enum
- record
- extends
- implements
- field
- static field
- static initializer
- instance initializer
- constructor
- method
- nested class
- nested interface
- nested enum
- nested record

## クラス関係

クラス間関係を調査するときは、単純なimportだけで判断しないこと。

必要に応じて以下を確認すること。

- extends
- implements
- interfaceの実装
- abstract class
- method override
- method overload
- generic type
- annotation
- factory
- dependency injection
- reflection

interfaceを発見した場合、処理内容の調査ではinterfaceの宣言だけで終了せず、必要に応じて実装クラスを特定すること。

## メソッド呼び出し

メソッドの処理を追跡するときは、可能な範囲で次を確認すること。

1. 呼び出し元
2. レシーバの実際の型
3. 宣言クラス
4. 実装クラス
5. 引数
6. 戻り値
7. 呼び出し先

継承、interface、overload、overrideが存在する場合は、どの実装が実行される可能性があるか確認すること。

実装を一意に決定できない場合は、一意に決定できないことを明記すること。

## Java以外の関連ファイル

Javaソースだけでは処理を確定できない場合は、必要に応じて以下も調査すること。

- properties
- XML
- YAML
- JSON
- SQL
- MANIFEST
- Eclipse設定
- classpath
- framework設定
- resourceファイル

Javaソースだけを見て推測で補完しないこと。

## 起動処理

本システムは1つの起動JARから起動される。

起動経路を調査するときは、必要に応じて以下を確認すること。

- MANIFEST.MF
- Main-Class
- public static void main(String[] args)
- 起動クラス
- 初期化処理
- DIコンテナ
- framework初期化
- 設定読込
- worker/thread生成
- scheduler
- listener

## Java調査結果

調査結果では、可能な限り次の形式で根拠を示すこと。

`ファイルパス`
→ `package`
→ `class/interface`
→ `method`
→ `呼び出し先`

処理が複数クラスにまたがる場合は、呼び出し順に整理すること。