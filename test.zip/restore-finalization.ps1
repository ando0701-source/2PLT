$ErrorActionPreference = 'Stop'

function Fail([string]$message) {
  Write-Host "[STOP] $message" -ForegroundColor Red
  exit 1
}

try {
  Write-Host 'Source Scope v0.3.5 - finalization-only recovery'
  Write-Host 'Use only for a run that finished generating JSON but failed to rename the .building folder.'
  $raw = Read-Host 'Paste the full .building folder path'
  if ([string]::IsNullOrWhiteSpace($raw)) { Fail 'Folder path not entered.' }
  $path = $raw.Trim().Trim('"')
  if (!$path.EndsWith('.building', [StringComparison]::OrdinalIgnoreCase)) { Fail 'The folder must end with .building.' }
  if (!(Test-Path -LiteralPath $path -PathType Container)) { Fail 'The folder does not exist.' }
  $path = (Get-Item -LiteralPath $path).FullName
  $dest = $path.Substring(0, $path.Length - '.building'.Length)
  if (Test-Path -LiteralPath $dest) { Fail 'Destination already exists. No change made.' }

  $logPath = Join-Path $path 'execution.log'
  $reportPath = Join-Path $path 'run-report.json'
  $csvPath = Join-Path $path 'diagnostics.csv'
  $indexPath = Join-Path $path 'fqcn-index.json'
  foreach ($f in @($logPath, $reportPath, $csvPath, $indexPath)) {
    if (!(Test-Path -LiteralPath $f -PathType Leaf)) { Fail "Required file missing: $f" }
  }

  $report = Get-Content -LiteralPath $reportPath -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($report.state -ne 'FAILED') { Fail 'The run-report state is not FAILED. No change made.' }
  $log = [System.IO.File]::ReadAllText($logPath, [System.Text.Encoding]::UTF8)
  $matchesForCount = [regex]::Matches($log, 'RUN_COMPLETE:[^\r\n]*?entries=(\d+)')
  if ($matchesForCount.Count -ne 1) { Fail 'Cannot confirm a unique RUN_COMPLETE entry count.' }
  $expected = [int]$matchesForCount[0].Groups[1].Value
  if (!$log.Contains('RUN_FAILED: cannot finalize result folder:')) {
    Fail 'No finalization-only failure marker. This run may have failed earlier.'
  }
  if ($log.Contains('RUN_FAILED: ') -and [regex]::Matches($log, 'RUN_FAILED: ').Count -ne 1) {
    Fail 'More than one RUN_FAILED marker found. Manual review required.'
  }

  $layer1Path = Join-Path $path 'layer1'
  $layer2Path = Join-Path $path 'layer2'
  if (!(Test-Path -LiteralPath $layer1Path -PathType Container) -or
      !(Test-Path -LiteralPath $layer2Path -PathType Container)) {
    Fail 'Layer output folders are missing.'
  }
  $count1 = @(Get-ChildItem -LiteralPath $layer1Path -Recurse -File -Filter '*.json').Count
  $count2 = @(Get-ChildItem -LiteralPath $layer2Path -Recurse -File -Filter '*.json').Count
  $partial = @(Get-ChildItem -LiteralPath $path -Recurse -File -Filter '*.part').Count
  Write-Host "Expected entries: $expected"
  Write-Host "layer1 JSON: $count1  layer2 JSON: $count2  temporary .part: $partial"
  if ($expected -le 0 -or $count1 -ne $expected -or $count2 -ne $expected -or $partial -ne 0) {
    Fail 'Output counts are not consistent. Do not recover automatically.'
  }
  $answer = Read-Host 'Checks passed. Close Explorer, Excel, and editors using this folder; then type YES to restore'
  if ($answer -cne 'YES') { Fail 'Canceled. No change made.' }

  # Keep the original failure report, even after successful recovery.
  Copy-Item -LiteralPath $reportPath -Destination (Join-Path $path 'run-report.before-recovery.json')
  try {
    Rename-Item -LiteralPath $path -NewName ([System.IO.Path]::GetFileName($dest)) -ErrorAction Stop
  } catch {
    Fail "Rename failed: $($_.Exception.Message). Close any programs using this folder and try again. The original files remain in .building."
  }

  $recoveredReportPath = Join-Path $dest 'run-report.json'
  $recovered = Get-Content -LiteralPath $recoveredReportPath -Raw -Encoding UTF8 | ConvertFrom-Json
  $oldError = [string]$recovered.error
  $recovered | Add-Member -MemberType NoteProperty -Name state -Value 'COMPLETE' -Force
  $recovered | Add-Member -MemberType NoteProperty -Name entry_count -Value $expected -Force
  $recovered | Add-Member -MemberType NoteProperty -Name recovered_from_finalization_error -Value $true -Force
  $recovered | Add-Member -MemberType NoteProperty -Name recovered_utc -Value ([DateTime]::UtcNow.ToString('o')) -Force
  $recovered | Add-Member -MemberType NoteProperty -Name original_finalization_error -Value $oldError -Force
  $recovered | Add-Member -MemberType NoteProperty -Name original_metrics_not_restored -Value $true -Force
  $recovered.PSObject.Properties.Remove('error')
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($recoveredReportPath, ($recovered | ConvertTo-Json -Depth 15), $utf8)
  Write-Host '[PASS] Results recovered. The original failure report is saved.' -ForegroundColor Green
  Write-Host "Result folder: $dest"
  Write-Host 'Important: the recovery verifies JSON output counts, not dependency accuracy.'
  exit 0
} catch {
  Fail $_.Exception.Message
}
