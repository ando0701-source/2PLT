@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
set "KIT=%~dp0"
set "JAVA_EXE=java"
set "JAVAC_EXE=javac"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" (
  set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
  set "JAVAC_EXE=%JAVA_HOME%\bin\javac.exe"
)
"%JAVAC_EXE%" -version >nul 2>&1
if errorlevel 1 (
  echo.
  echo [STOP] Java Development Kit (JDK 11 or newer) is needed to CREATE analysis JSON.
  echo Use your installed JDK 11 (including OpenJ9). Set JAVA_HOME if needed.
  echo Java is NOT needed later for reading the generated JSON.
  pause
  exit /b 1
)
"%JAVA_EXE%" --add-modules jdk.compiler -jar "%KIT%bin\source-scope.jar" check
if errorlevel 1 (
  echo [STOP] JDK 11 or newer with the compiler module is required.
  pause
  exit /b 1
)
echo ===========================================================
echo   Source Scope - Java source dependency analysis
echo ===========================================================
echo.
echo Enter the folder containing the Java project.
echo Tip: You can drag and drop the folder into this window.
set /p "SRC=Project folder: "
set "SRC=%SRC:"=%"
if not exist "%SRC%\." (
  echo [STOP] Folder does not exist: "%SRC%"
  pause
  exit /b 1
)
set "REL=11"
set /p "REL=Java version in your project [11]: "
if "%REL%"=="" set "REL=11"
set "ENC=UTF-8"
set /p "ENC=Source encoding [UTF-8] (MS932 for Shift-JIS): "
if "%ENC%"=="" set "ENC=UTF-8"
set "DEST=%USERPROFILE%\SourceScopeResults"
if not exist "%DEST%" mkdir "%DEST%"
for /f "delims=" %%A in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%A"
if not defined STAMP set "STAMP=%RANDOM%_%RANDOM%"
set "OUT=%DEST%\run-%STAMP%-%RANDOM%"
echo.
echo Input folder: "%SRC%"
echo Output folder: "%OUT%"
echo Processing may take time for large projects. Keep this window open.
echo.
"%JAVA_EXE%" --add-modules jdk.compiler -Xmx4g -jar "%KIT%bin\source-scope.jar" analyze --root "%SRC%" --out "%OUT%" --all --release "%REL%" --encoding "%ENC%"
if errorlevel 1 (
  echo.
  echo [STOP] Analysis failed. See the ERROR message above.
  echo Do not use a .building folder as a completed result.
  pause
  exit /b 1
)
echo.
echo [DONE] Completed result folder:
echo "%OUT%"
echo See 50_利用手順書.md for how to open the JSON.
pause
