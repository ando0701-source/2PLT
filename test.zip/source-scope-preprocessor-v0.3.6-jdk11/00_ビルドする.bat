@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
set "KIT=%~dp0"
set "JAVA_EXE=java"
set "JAVAC_EXE=javac"
set "JAR_EXE=jar"

rem Use one consistent JDK from JAVA_HOME when all three commands exist.
if not defined JAVA_HOME goto CHECK_TOOLS
if not exist "%JAVA_HOME%\bin\java.exe" goto CHECK_TOOLS
if not exist "%JAVA_HOME%\bin\javac.exe" goto CHECK_TOOLS
if not exist "%JAVA_HOME%\bin\jar.exe" goto CHECK_TOOLS
set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
set "JAVAC_EXE=%JAVA_HOME%\bin\javac.exe"
set "JAR_EXE=%JAVA_HOME%\bin\jar.exe"

:CHECK_TOOLS
"%JAVA_EXE%" -version >nul 2>&1
if errorlevel 1 goto ERROR_JDK
"%JAVAC_EXE%" -version >nul 2>&1
if errorlevel 1 goto ERROR_JDK
"%JAR_EXE%" --help >nul 2>&1
if errorlevel 1 goto ERROR_JDK
if not exist "%KIT%src\main\java\sourcescope\Main.java" goto ERROR_SOURCE

echo ===========================================================
echo   Source Scope - optional JAR build for JDK 11+
echo ===========================================================
echo.
echo This operation rebuilds bin\source-scope.jar from src.
echo Java source and existing analysis results are not modified.
echo.

set "CLASSES=%KIT%build\classes-00"
set "STAGED_JAR=%KIT%build\source-scope-staged.jar"
if not exist "%KIT%build\." mkdir "%KIT%build"
if errorlevel 1 goto ERROR_PREPARE
if exist "%CLASSES%\." rmdir /s /q "%CLASSES%"
if exist "%CLASSES%\." goto ERROR_PREPARE
mkdir "%CLASSES%"
if errorlevel 1 goto ERROR_PREPARE
if exist "%STAGED_JAR%" del /q "%STAGED_JAR%"
if exist "%STAGED_JAR%" goto ERROR_PREPARE

echo [1/3] Compiling Java sources with --release 11 ...
rem Compiling Main.java with -sourcepath also compiles referenced helper sources.
"%JAVAC_EXE%" --release 11 -encoding UTF-8 -sourcepath "%KIT%src\main\java" -d "%CLASSES%" "%KIT%src\main\java\sourcescope\Main.java"
if errorlevel 1 goto ERROR_COMPILE
if not exist "%CLASSES%\sourcescope\Main.class" goto ERROR_COMPILE

echo [2/3] Packaging executable JAR ...
"%JAR_EXE%" --create --file "%STAGED_JAR%" --main-class sourcescope.Main -C "%CLASSES%" .
if errorlevel 1 goto ERROR_PACKAGE
if not exist "%STAGED_JAR%" goto ERROR_PACKAGE

echo [3/3] Verifying compiled JAR ...
"%JAVA_EXE%" --add-modules jdk.compiler -jar "%STAGED_JAR%" check
if errorlevel 1 goto ERROR_CHECK
if not exist "%KIT%bin\." mkdir "%KIT%bin"
if errorlevel 1 goto ERROR_INSTALL
move /Y "%STAGED_JAR%" "%KIT%bin\source-scope.jar" >nul
if errorlevel 1 goto ERROR_INSTALL

echo.
echo [PASS] Built: "%KIT%bin\source-scope.jar"
echo Next: Run 03_ sample-check batch before analyzing your project.
pause
exit /b 0

:ERROR_JDK
echo [STOP] A full JDK 11 or newer is required (java, javac, jar).
echo Set JAVA_HOME to your existing JDK if needed.
goto FAIL
:ERROR_SOURCE
echo [STOP] src\main\java\sourcescope\Main.java was not found.
echo Extract the complete ZIP before building.
goto FAIL
:ERROR_PREPARE
echo [FAIL] Could not prepare the build folder.
goto FAIL
:ERROR_COMPILE
echo [FAIL] Java compilation failed. Existing JAR was not replaced.
goto FAIL
:ERROR_PACKAGE
echo [FAIL] JAR packaging failed. Existing JAR was not replaced.
goto FAIL
:ERROR_CHECK
echo [FAIL] JAR verification failed. Existing JAR was not replaced.
goto FAIL
:ERROR_INSTALL
echo [FAIL] Could not update bin\source-scope.jar.
echo Close any running Source Scope process and check folder permissions.
goto FAIL
:FAIL
echo.
pause
exit /b 1
