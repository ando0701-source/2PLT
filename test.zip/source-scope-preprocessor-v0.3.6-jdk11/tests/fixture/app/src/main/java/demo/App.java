package demo;
import demo.vendor.Library;
import demo.common.Helper;
import demo.mapper.UserMapper;
public class App {
  private Library externalLibrary;

 private final Helper helper=new Helper();
 private UserMapper mapper;
 public String message(){return helper.hello();}
}
