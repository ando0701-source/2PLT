@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
set "JAVA_EXE=java"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
set "ROOT=%USERPROFILE%\SourceScopeResults"
set "LATEST="
for /f "delims=" %%D in ('dir /b /ad /o-d "%ROOT%\run-*" 2^>nul') do if not defined LATEST if /I not "%%~xD"==".building" set "LATEST=%ROOT%\%%D"
echo Enter the completed output folder (Enter uses the newest one).
echo Default: "%LATEST%"
set /p "OUT=Output folder: "
set "OUT=%OUT:"=%"
if "%OUT%"=="" set "OUT=%LATEST%"
if not exist "%OUT%\fqcn-index.json" (
  echo [STOP] Cannot find fqcn-index.json in this folder.
  pause
  exit /b 1
)
echo Example FQCN: demo.App
set /p "NAME=FQCN: "
if "%NAME%"=="" (echo [STOP] Enter an FQCN.& pause & exit /b 1)
"%JAVA_EXE%" -jar "%~dp0bin\source-scope.jar" lookup --out "%OUT%" --fqcn "%NAME%"
echo.
echo You can open the files shown as layer1 and layer2 with a text editor.
pause
