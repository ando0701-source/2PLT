package sourcescope;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.util.zip.*;

/** Offline, auditable JAR discovery. Never adds an unmatched JAR to a compiler classpath. */
final class JarCatalog {
  static final class JarInfo {
    Path path;
    String uri, status="CANDIDATE", reason="No matching POM compile/provided dependency";
    String coordinates="";
    final Set<String> gavs=new LinkedHashSet<>();
    final Set<String> referencedBy=new TreeSet<>();
    int classCount=0, internalCount=0;
    boolean unreadable=false;
    JarInfo(Path p,String uri){this.path=p;this.uri=uri;}
  }
  static final class Resolution {
    final JarInfo jar; final String code,reason;
    Resolution(JarInfo j,String c,String r){jar=j;code=c;reason=r;}
    boolean found(){return jar!=null;}
  }
  final Path root;
  final List<JarInfo> jars=new ArrayList<>();
  final List<String> internalPrefixes=new ArrayList<>();
  final List<Map<String,Object>> globalIssues=new ArrayList<>();
  final Map<String,List<JarInfo>> metaIndex=new HashMap<>();
  final Map<String,List<JarInfo>> nameIndex=new HashMap<>();
  final Map<Path,JarInfo> byPath=new HashMap<>();
  final Set<Path> consumed=new HashSet<>();
  int duplicateClassCount=0;

  JarCatalog(Path root, PomGraph poms) throws IOException {
    this.root=root;
    Path config=root.resolve("config/internal-packages.txt");
    if(Files.isRegularFile(config)) {
      for(String raw:Files.readAllLines(config,StandardCharsets.UTF_8)){
        String s=raw.replace("\ufeff", "").trim();int comment=s.indexOf('#');if(comment>=0)s=s.substring(0,comment).trim();
        if(s.isEmpty())continue;
        if(!s.matches("[A-Za-z_$][\\w$]*(\\.[A-Za-z_$][\\w$]*)*"))
          throw new IOException("Invalid internal package in "+config+": "+s);
        if(!internalPrefixes.contains(s))internalPrefixes.add(s);
      }
    }
    System.out.println("  Internal package prefixes: "+internalPrefixes.size());
    List<Path> candidates=scanJarFiles(root);
    System.out.println("  JAR candidates found: "+candidates.size());
    int processed=0;
    for(Path p:candidates){
      JarInfo info=new JarInfo(p,Support.uri(root,p));jars.add(info);byPath.put(p,info);
      if(info.uri.contains("/.") || info.uri.endsWith("-sources.jar") || info.uri.endsWith("-javadoc.jar") || info.uri.endsWith("-tests.jar")){
        info.status="EXCLUDED_CLASSIFIER";info.reason="Non-runtime classifier or hidden path";
      }
      try(JarFile zip=new JarFile(p.toFile(),false)) {
        Enumeration<JarEntry> all=zip.entries();
        while(all.hasMoreElements()){
          JarEntry e=all.nextElement();String name=e.getName();
          if(name.endsWith(".class") && !e.isDirectory()){
            info.classCount++;
            String fqcn=className(name);
            if(internal(fqcn))info.internalCount++;
          }
          if(name.startsWith("META-INF/maven/") && name.endsWith("/pom.properties")){
            Properties props=new Properties();
            try(InputStream input=zip.getInputStream(e)){props.load(input);}
            String g=props.getProperty("groupId","").trim(),a=props.getProperty("artifactId","").trim(),v=props.getProperty("version","").trim();
            if(!g.isEmpty()&&!a.isEmpty()&&!v.isEmpty())info.gavs.add(g+":"+a+":"+v);
          }
        }
      }catch(Exception ex){info.unreadable=true;info.status="INVALID_JAR";info.reason=ex.toString();
        globalIssues.add(Support.diag("EXTERNAL_JAR_INVALID",info.uri,ex.toString()));}
      if(!info.unreadable && info.internalCount>0){info.status="EXCLUDED_INTERNAL_PACKAGE";
        info.reason="Contains "+info.internalCount+" class(es) in configured internal packages";}
      if(!info.unreadable && info.status.equals("CANDIDATE") && isGenerated(p,info,poms)){
        info.status="EXCLUDED_LOCAL_OUTPUT";info.reason="Matches a locally generated POM artifact";}
      info.coordinates=String.join(";",info.gavs);
      if(!info.unreadable && info.status.equals("CANDIDATE")){
        // A shaded JAR can embed pom.properties for many *other* libraries.
        // Only index the unique identity or the one matching its own filename.
        for(String gav:info.gavs){
          String[] parts=gav.split(":",3);
          if(info.gavs.size()==1 || (parts.length==3 && p.getFileName().toString().equals(parts[1]+"-"+parts[2]+".jar")))
            metaIndex.computeIfAbsent(gav,k->new ArrayList<>()).add(info);
        }
        nameIndex.computeIfAbsent(p.getFileName().toString(),k->new ArrayList<>()).add(info);
      }
      processed++;if(processed%100==0 || processed==candidates.size())System.out.println(
        "  JAR indexing: "+processed+" / "+candidates.size()+" ("+Main.percent(processed,candidates.size())+"%)");
    }
  }
  static String className(String entry){
    String name=entry;
    if(name.startsWith("META-INF/versions/")){
      int slash=name.indexOf('/',"META-INF/versions/".length());
      if(slash<0)return "";
      name=name.substring(slash+1);
    }
    return name.substring(0,name.length()-6).replace('/','.');
  }
  boolean internal(String fqcn){for(String prefix:internalPrefixes)if(fqcn.startsWith(prefix+"."))return true;return false;}
  private boolean isGenerated(Path file,JarInfo j,PomGraph poms){
    for(PomGraph.Pom pom:poms.poms.values()){
      if(pom.artifact.isEmpty() || pom.version.isEmpty())continue;
      String base=pom.artifact+"-"+pom.version;
      String name=file.getFileName().toString();
      if(!name.equals(base+".jar") && !name.startsWith(base+"-"))continue;
      String gav=pom.group+":"+pom.artifact+":"+pom.version;
      if(!j.gavs.isEmpty() && !j.gavs.contains(gav))continue;
      // Only exclude an artifact when it is generated inside the module's own target/build directory,
      // or its embedded Maven coordinates exactly match a local POM.
      if(j.gavs.contains(gav) || file.startsWith(pom.path.getParent().resolve("target")) ||
          file.startsWith(pom.path.getParent().resolve("build")))return true;
    }
    return false;
  }
  static List<Path> scanJarFiles(Path root) throws IOException {
    List<Path> out=new ArrayList<>();
    Files.walkFileTree(root,new SimpleFileVisitor<Path>(){
      @Override public FileVisitResult preVisitDirectory(Path dir,java.nio.file.attribute.BasicFileAttributes attr){
        if(!dir.equals(root)&&Set.of(".git",".gradle","node_modules",".idea").contains(dir.getFileName().toString()))return FileVisitResult.SKIP_SUBTREE;
        return FileVisitResult.CONTINUE;
      }
      @Override public FileVisitResult visitFile(Path path,java.nio.file.attribute.BasicFileAttributes attr)throws IOException{
        if(attr.isRegularFile() && path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")){
          Path real=path.toRealPath();if(real.startsWith(root))out.add(real);
        }return FileVisitResult.CONTINUE;
      }
    });
    out.sort(Comparator.comparing(p->Support.uri(root,p)));return out;
  }
  Resolution resolve(String g,String a,String v,String classifier,String type,String pomUri){
    if(!type.isEmpty() && !type.equals("jar"))return new Resolution(null,"EXTERNAL_DEPENDENCY_NON_JAR","Dependency type is "+type);
    if(!classifier.isEmpty())return new Resolution(null,"EXTERNAL_DEPENDENCY_CLASSIFIER_UNVERIFIED","Classifier: "+classifier);
    if(g.isEmpty()||a.isEmpty()||v.isEmpty()||g.contains("${")||a.contains("${")||v.contains("${"))
      return new Resolution(null,"EXTERNAL_DEPENDENCY_COORDINATES_UNRESOLVED","Missing or unresolved dependency coordinates: "+g+":"+a+":"+v);
    List<JarInfo> matches=metaIndex.getOrDefault(g+":"+a+":"+v,List.of());
    if(matches.isEmpty()){
      // Filename fallback is allowed only when embedded Maven coordinates are absent.
      List<JarInfo> names=nameIndex.getOrDefault(a+"-"+v+".jar",List.of());
      List<JarInfo> withoutMetadata=new ArrayList<>();
      for(JarInfo j:names)if(j.gavs.isEmpty())withoutMetadata.add(j);
      if(!names.isEmpty() && withoutMetadata.isEmpty())return new Resolution(null,
        "EXTERNAL_JAR_COORDINATES_MISMATCH","Filename matches, but embedded Maven coordinates differ: "+g+":"+a+":"+v);
      matches=withoutMetadata;
    }
    if(matches.size()!=1){
      if(matches.isEmpty())for(JarInfo j:jars){
        if(j.status.startsWith("EXCLUDED") && (j.gavs.contains(g+":"+a+":"+v) ||
          j.path.getFileName().toString().equals(a+"-"+v+".jar")))
          return new Resolution(null,"EXTERNAL_JAR_EXCLUDED", "JAR is "+j.status+": "+j.uri);
      }
      return new Resolution(null,matches.isEmpty()?"EXTERNAL_JAR_NOT_FOUND":"EXTERNAL_JAR_AMBIGUOUS",
        "Matching JARs="+matches.size()+" for "+g+":"+a+":"+v);
    }
    JarInfo result=matches.get(0);result.status="ADOPTED";result.reason="Matched POM dependency by "+
      (result.gavs.contains(g+":"+a+":"+v)?"embedded Maven coordinates":"exact artifact-version filename");
    result.referencedBy.add(pomUri);consumed.add(result.path);
    return new Resolution(result,"RESOLVED_EXTERNAL",result.reason);
  }
  void verifyClassCollisions() throws IOException {
    HashMap<String,String> owner=new HashMap<>();
    Set<String> emitted=new HashSet<>();
    int scanned=0, indexed=0;boolean indexCapped=false;
    final int MAX_CLASS_INDEX=500000;
    for(JarInfo info:jars)if(info.status.equals("ADOPTED")){
      try(JarFile jar=new JarFile(info.path.toFile(),false)){
        Enumeration<JarEntry> it=jar.entries();while(it.hasMoreElements()){
          String n=it.nextElement().getName();if(!n.endsWith(".class") || n.startsWith("META-INF/versions/"))continue;
          String fqcn=className(n);String previous=owner.get(fqcn);
          if(previous==null && owner.size()<MAX_CLASS_INDEX){owner.put(fqcn,info.uri);indexed++;}
          else if(previous==null)indexCapped=true;
          if(previous!=null && !previous.equals(info.uri)&&emitted.add(fqcn)){
            duplicateClassCount++;
            if(duplicateClassCount<=200){Map<String,Object> diag=Support.diag("EXTERNAL_JAR_CLASS_DUPLICATE",info.uri,
              fqcn+" also in "+previous);diag.put("severity","WARNING");globalIssues.add(diag);}
          }
        }
      }
      scanned++;
    }
    if(duplicateClassCount>200){Map<String,Object> diag=Support.diag("EXTERNAL_JAR_CLASS_DUPLICATE_TRUNCATED","",
      "Only first 200 of "+duplicateClassCount+" duplicate class names were reported");
      diag.put("severity","WARNING");globalIssues.add(diag);}
    if(indexCapped){Map<String,Object> diag=Support.diag("EXTERNAL_JAR_CLASS_CHECK_PARTIAL","",
      "Duplicate check indexed at most "+MAX_CLASS_INDEX+" class names for memory safety");
      diag.put("severity","WARNING");globalIssues.add(diag);}
    System.out.println("  Adopted JAR class check: "+scanned+" JAR(s), duplicate classes="+duplicateClassCount);
  }
  void writeReports(Path output) throws IOException {
    try(Writer w=new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(output.resolve("external-libraries.csv")),StandardCharsets.UTF_8))){
      w.write('\ufeff');w.write("jar_uri,status,maven_coordinates,class_count,internal_class_count,referenced_poms,reason\r\n");
      for(JarInfo j:jars){
        List<String> cols=List.of(j.uri,j.status,j.coordinates,String.valueOf(j.classCount),String.valueOf(j.internalCount),String.join(";",j.referencedBy),j.reason);
        for(int i=0;i<cols.size();i++){if(i>0)w.write(',');DiagnosticsReport.csv(w,cols.get(i));}
        w.write("\r\n");
      }
    }
    try(Writer w=new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(output.resolve("external-library-violations.csv")),StandardCharsets.UTF_8))){
      w.write('\ufeff');w.write("jar_uri,fqcn,reason\r\n");
      for(JarInfo j:jars)if(j.internalCount>0&&!j.unreadable){
        try(JarFile jar=new JarFile(j.path.toFile(),false)){
          Enumeration<JarEntry> it=jar.entries();while(it.hasMoreElements()){
            String name=it.nextElement().getName();if(!name.endsWith(".class"))continue;
            String fqcn=className(name);if(!internal(fqcn))continue;
            DiagnosticsReport.csv(w,j.uri);w.write(',');DiagnosticsReport.csv(w,fqcn);w.write(',');
            DiagnosticsReport.csv(w,"INTERNAL_PACKAGE");w.write("\r\n");
          }
        }
      }
    }
  }
  int adopted(){return consumed.size();}
}
