package sourcescope;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** A single CSV row per distinct cause and layer, not per referring entry. */
final class DiagnosticsReport {
  static final class Item {
    final String layer, severity, code, sourceUri, message;
    long affectedEntryCount;
    Item(String layer,String severity,String code,String sourceUri,String message){
      this.layer=layer;this.severity=severity;this.code=code;this.sourceUri=sourceUri;this.message=message;
    }
  }
  private final TreeMap<String,Item> items=new TreeMap<>();
  private String id(String layer,String severity,String code,String uri,String msg){
    return layer+"\u0000"+severity+"\u0000"+code+"\u0000"+uri+"\u0000"+msg;
  }
  void affected(String layer,List<Map<String,Object>> diagnoses){
    // A cause may occur more than once inside a single closure; count the entry once.
    Set<String> seen=new HashSet<>();
    for(Map<String,Object> d:diagnoses){
      String sev=field(d,"severity"),code=field(d,"code"),uri=field(d,"source_uri"),msg=field(d,"message");
      String key=id(layer,sev,code,uri,msg);
      if(seen.add(key))items.computeIfAbsent(key,k->new Item(layer,sev,code,uri,msg)).affectedEntryCount++;
    }
  }
  void global(String layer,String code,String sourceUri,String message){global(layer,"ERROR",code,sourceUri,message);}
  void global(String layer,String severity,String code,String sourceUri,String message){
    String key=id(layer,severity,code,sourceUri,message);
    items.computeIfAbsent(key,k->new Item(layer,severity,code,sourceUri,message));
  }
  private String field(Map<String,Object> d,String key){Object x=d.get(key);return x==null?"":x.toString();}
  int uniqueCount(){return items.size();}
  void write(Path csv) throws IOException {
    Files.createDirectories(csv.getParent());
    try(Writer writer=new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(csv),StandardCharsets.UTF_8))){
      // UTF-8 BOM allows double-click opening in older Windows Excel versions.
      writer.write('\ufeff');
      writer.write("layer,severity,code,source_uri,message,affected_entry_count\r\n");
      for(Item i:items.values()){
        csv(writer,i.layer);writer.write(',');csv(writer,i.severity);writer.write(',');
        csv(writer,i.code);writer.write(',');csv(writer,i.sourceUri);writer.write(',');
        csv(writer,i.message);writer.write(',');writer.write(Long.toString(i.affectedEntryCount));writer.write("\r\n");
      }
    }
  }
  static void csv(Writer w,String value)throws IOException {
    w.write('"');w.write(value.replace("\"","\"\""));w.write('"');
  }
}
