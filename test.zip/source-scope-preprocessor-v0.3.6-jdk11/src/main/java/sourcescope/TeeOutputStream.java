package sourcescope;

import java.io.*;

/** Mirrors application output to both a console and a shared run log. */
final class TeeOutputStream extends OutputStream {
  private final OutputStream console,log;
  TeeOutputStream(OutputStream console,OutputStream log){this.console=console;this.log=log;}
  @Override public void write(int value)throws IOException {
    synchronized(log){ console.write(value); log.write(value); }
  }
  @Override public void write(byte[] b,int off,int len)throws IOException {
    synchronized(log){ console.write(b,off,len); log.write(b,off,len); }
  }
  @Override public void flush()throws IOException {
    synchronized(log){console.flush();log.flush();}
  }
  @Override public void close()throws IOException {flush();}
}
