package sourcescope;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.w3c.dom.*;

final class PomGraph {
  static final class Pom {
    Path path; Pom parent; String group="",artifact="",version="", sourceDir="src/main/java",release="";
    List<Dependency> dependencies=new ArrayList<>(); List<Pom> localDeps=new ArrayList<>();
    Map<String,String> props=new HashMap<>();List<Map<String,Object>> issues=new ArrayList<>();
    Element raw; boolean resolved=false, visiting=false;
    Pom(Path path,Element raw){this.path=path;this.raw=raw;}
    String ga(){return group+":"+artifact;}
  }
  static final class Dependency {
    String group,artifact,version,scope,type,classifier;
    Dependency(Element e){group=Support.text(e,"groupId","");artifact=Support.text(e,"artifactId","");
      version=Support.text(e,"version","");scope=Support.text(e,"scope","compile");
      type=Support.text(e,"type","jar");classifier=Support.text(e,"classifier","");}
  }
  final Path root; final TreeMap<Path,Pom> poms=new TreeMap<>();
  final Map<String,List<Pom>> gaIndex=new HashMap<>();final Map<Path,String> invalidPoms=new HashMap<>();
  final Map<Path,Pom> ownerCache=new HashMap<>();final Map<Pom,List<Pom>> visibleCache=new HashMap<>();
  final Map<Pom,List<Path>> jarDeps=new HashMap<>();
  final Map<Pom,List<Dependency>> pendingExternal=new HashMap<>();
  final Map<Pom,List<Path>> classpathCache=new HashMap<>();
  final Map<Pom,List<Map<String,Object>>> diagnosisCache=new HashMap<>();final Map<Pom,List<String>> relatedCache=new HashMap<>();
  PomGraph(Path root,List<Path> paths){this.root=root;
    for(Path path:paths){try {Document doc=Support.xml(path);if(Support.name(doc.getDocumentElement()).equals("project"))poms.put(path,new Pom(path,doc.getDocumentElement()));}
      catch(IOException ex){invalidPoms.put(path,ex.getMessage());System.err.println("WARN: POM: "+ex.getMessage()); }}
    for(Pom pom:poms.values())effective(pom);
    for(Pom p:poms.values())gaIndex.computeIfAbsent(p.ga(), k->new ArrayList<>()).add(p);
    for(Pom p:poms.values())for(Dependency d:p.dependencies){if(!Set.of("compile","provided").contains(d.scope))continue;
      List<Pom> same=gaIndex.getOrDefault(expand(d.group,p)+":"+expand(d.artifact,p),List.of());
      List<Pom> matches=new ArrayList<>();for(Pom candidate:same)if(d.version.isEmpty() || expand(d.version,p).equals(candidate.version))matches.add(candidate);
      if(matches.size()==1) p.localDeps.add(matches.get(0));
      else if(matches.size()>1)p.issues.add(Support.diag("POM_GAV_COLLISION",uri(p),"Multiple local modules match "+d.group+":"+d.artifact));
      else pendingExternal.computeIfAbsent(p,k->new ArrayList<>()).add(d);
    }
  }

  void resolveJars(JarCatalog jars){
    for(var pair:pendingExternal.entrySet()){
      Pom p=pair.getKey();
      for(Dependency d:pair.getValue()){
        String g=expand(d.group,p),a=expand(d.artifact,p),v=expand(d.version,p);
        JarCatalog.Resolution result=jars.resolve(g,a,v,expand(d.classifier,p),expand(d.type,p),uri(p));
        if(result.found())jarDeps.computeIfAbsent(p,k->new ArrayList<>()).add(result.jar.path);
        else if(!result.code.equals("EXTERNAL_DEPENDENCY_NON_JAR"))
          p.issues.add(Support.diag(result.code,uri(p),result.reason));
      }
    }
    diagnosisCache.clear();classpathCache.clear();
  }
  List<Path> classpathFor(Pom p){
    if(classpathCache.containsKey(p))return classpathCache.get(p);
    TreeSet<Path> result=new TreeSet<>();
    for(Pom x:visible(p))result.addAll(jarDeps.getOrDefault(x,List.of()));
    List<Path> paths=new ArrayList<>(result);classpathCache.put(p,paths);return paths;
  }
  String uri(Pom p){return Support.uri(root,p.path);}
  void effective(Pom p){if(p.resolved)return;if(p.visiting){p.issues.add(Support.diag("POM_PARENT_CYCLE",uri(p),"Cyclic parent POM"));return;}
    p.visiting=true;Element parent=Support.child(p.raw,"parent");
    if(parent!=null){String rel=Support.text(parent,"relativePath","../pom.xml");if(!rel.isEmpty()){
      Path candidate=p.path.getParent().resolve(rel).normalize();if(Files.isDirectory(candidate))candidate=candidate.resolve("pom.xml");
      Pom found=poms.get(candidate);if(found!=null && found!=p){effective(found);p.parent=found;p.props.putAll(found.props);p.release=found.release;p.sourceDir=found.sourceDir;p.dependencies.addAll(found.dependencies);
        String expectedGroup=Support.text(parent,"groupId","");String expectedArtifact=Support.text(parent,"artifactId","");
        String expectedVersion=Support.text(parent,"version","");
        if(!found.group.equals(expectedGroup) || !found.artifact.equals(expectedArtifact) || !found.version.equals(expectedVersion))
          p.issues.add(Support.diag("POM_PARENT_COORDINATE_MISMATCH",uri(p),"Local parent coordinates do not match parent declaration"));
      }
      else p.issues.add(Support.diag("POM_PARENT_MISSING",uri(p),"Parent not found locally: "+rel));
    }else p.issues.add(Support.diag("POM_PARENT_MISSING",uri(p),"Parent requires external repository"));}
    Element props=Support.child(p.raw,"properties");for(Element x:Support.children(props,null))p.props.put(Support.name(x),x.getTextContent().trim());
    p.group=expand(Support.text(p.raw,"groupId",parent!=null?Support.text(parent,"groupId",""):""),p);
    p.artifact=expand(Support.text(p.raw,"artifactId",""),p);
    p.version=expand(Support.text(p.raw,"version",parent!=null?Support.text(parent,"version",""):""),p);
    p.props.put("project.groupId",p.group);p.props.put("project.artifactId",p.artifact);p.props.put("project.version",p.version);
    Element build=Support.child(p.raw,"build");p.sourceDir=expand(Support.text(build,"sourceDirectory",p.sourceDir),p);
    String r=p.props.getOrDefault("maven.compiler.release",p.props.getOrDefault("maven.compiler.source",p.release));
    Element compilerPlugins=Support.child(build,"plugins");
    for(Element plugin:Support.children(compilerPlugins,"plugin"))if(Support.text(plugin,"artifactId","").equals("maven-compiler-plugin")){
      Element cfg=Support.child(plugin,"configuration");r=Support.text(cfg,"release",Support.text(cfg,"source",r));
    }
    p.release=expand(r,p);
    for(Element e:Support.children(Support.child(p.raw,"dependencies"),"dependency"))p.dependencies.add(new Dependency(e));
    if(Support.child(p.raw,"profiles")!=null)p.issues.add(Support.diag("POM_PROFILE_UNRESOLVED",uri(p),"Profiles are not evaluated in this offline version"));
    Element dm=Support.child(Support.child(p.raw,"dependencyManagement"),"dependencies");
    if(dm!=null && !Support.children(dm,"dependency").isEmpty()) p.issues.add(Support.diag("POM_MANAGEMENT_UNVERIFIED",uri(p),"dependencyManagement/BOM is not fully resolved"));
    if(Support.child(build,"plugins")!=null)for(Element plugin:Support.children(Support.child(build,"plugins"),"plugin"))
      if(!Support.text(plugin,"artifactId","").equals("maven-compiler-plugin")){
        p.issues.add(Support.diag("POM_PLUGIN_UNVERIFIED",uri(p),"Plugin execution / generated sources not evaluated"));break;}
    p.resolved=true;p.visiting=false;
  }
  String expand(String s,Pom p){for(int i=0;i<8 && s.contains("${");i++){
      String old=s;for(var x:p.props.entrySet())s=s.replace("${"+x.getKey()+"}",x.getValue());if(old.equals(s))break;
    }return s;}
  Pom owner(Path java){if(ownerCache.containsKey(java))return ownerCache.get(java);Pom best=null;int length=-1;
    for(Pom p:poms.values()){Path base=p.path.getParent();if(java.startsWith(base)&&base.getNameCount()>length){
      best=p;length=base.getNameCount();}}
    ownerCache.put(java,best);return best;
  }
  List<Pom> visible(Pom p){if(visibleCache.containsKey(p))return visibleCache.get(p);LinkedHashSet<Pom> all=new LinkedHashSet<>();if(p!=null){Deque<Pom> queue=new ArrayDeque<>();queue.add(p);
    while(!queue.isEmpty()){Pom x=queue.removeFirst();if(all.add(x))queue.addAll(x.localDeps);}}List<Pom> result=new ArrayList<>(all);visibleCache.put(p,result);return result;}
  List<Map<String,Object>> diagnostics(Pom p){if(diagnosisCache.containsKey(p))return diagnosisCache.get(p);ArrayList<Map<String,Object>> out=new ArrayList<>();
    for(Pom x:visible(p)){for(Pom par=x;par!=null;par=par.parent)out.addAll(par.issues);}
    diagnosisCache.put(p,out);return out;
  }
  List<Map<String,Object>> invalidFor(Path source){List<Map<String,Object>> out=new ArrayList<>();
    for(var item:invalidPoms.entrySet())if(source.startsWith(item.getKey().getParent()))
      out.add(Support.diag("POM_XML_INVALID",Support.uri(root,item.getKey()),item.getValue()));return out;
  }
  List<String> related(Set<Path> sourceFiles){Set<String> result=new TreeSet<>();
    for(Path file:sourceFiles){Pom x=owner(file);if(!relatedCache.containsKey(x)){Set<String> local=new TreeSet<>();
        for(Pom dep:visible(x))for(Pom par=dep;par!=null;par=par.parent)local.add(uri(par));relatedCache.put(x,new ArrayList<>(local));}
      result.addAll(relatedCache.get(x));}
    return new ArrayList<>(result);
  }
}
