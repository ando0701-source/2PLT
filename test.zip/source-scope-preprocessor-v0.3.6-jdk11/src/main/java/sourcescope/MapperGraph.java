package sourcescope;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.w3c.dom.*;

final class MapperGraph {
  static final class Mapper {
    Path path; String namespace;Map<String,Set<String>> refs=new HashMap<>();Set<String> ids=new HashSet<>();
    List<Map<String,Object>> issues=new ArrayList<>();
    Mapper(Path path,String ns){this.path=path;namespace=ns;}
  }
  final Path root;final Map<String,List<Mapper>> byNamespace=new TreeMap<>();final Map<Path,Mapper> all=new HashMap<>();
  final List<Map<String,Object>> inputIssues=new ArrayList<>();
  MapperGraph(Path root,List<Path> xmls){this.root=root;
    for(Path file:xmls){try {Document d=Support.xml(file);Element e=d.getDocumentElement();if(!Support.name(e).equals("mapper"))continue;
      String ns=e.getAttribute("namespace").trim();Mapper mapper=new Mapper(file,ns);all.put(file,mapper);
      if(ns.isEmpty()) mapper.issues.add(Support.diag("MAPPER_NAMESPACE_MISSING",uri(file),"Mapper namespace missing"));
      else byNamespace.computeIfAbsent(ns,k->new ArrayList<>()).add(mapper);
      NodeList nodes=e.getElementsByTagName("*");
      for(int i=0;i<nodes.getLength();i++){Element n=(Element)nodes.item(i);String id=n.getAttribute("id").trim();
        if(!id.isEmpty() && Set.of("select","insert","update","delete","sql","resultMap").contains(Support.name(n))){
          if(!mapper.ids.add(Support.name(n)+":"+id))mapper.issues.add(Support.diag("MAPPER_STATEMENT_COLLISION",uri(file),"Duplicate id: "+id));}
        for(String a:List.of("refid","resultMap","extends","select")){
          String v=n.getAttribute(a).trim();if(v.isEmpty())continue;
          for(String ref:v.split(",")){String text=ref.trim();if(text.isEmpty())continue;
            int dot=text.lastIndexOf('.');String target=dot>0?text.substring(0,dot):ns;
            if(!target.isEmpty())mapper.refs.computeIfAbsent(target,k->new HashSet<>()).add(text);
          }
        }
        if(Support.name(n).equals("cache-ref")){String target=n.getAttribute("namespace").trim();
          if(!target.isEmpty())mapper.refs.computeIfAbsent(target,k->new HashSet<>()).add(target);}
      }
    }catch(IOException ex){
      inputIssues.add(Support.diag("XML_READ_ERROR",Support.uri(root,file),ex.getMessage()));
      System.err.println("WARN: XML: "+ex.getMessage());}}
  }
  String uri(Path p){return Support.uri(root,p);}
  Map<String,List<String>> mappers(Set<String> fqcn,Set<Path> direct,List<Map<String,Object>> issues){
    Map<String,List<String>> result=new TreeMap<>();
    for(String name:new TreeSet<>(fqcn)){
      List<Mapper> entries=byNamespace.getOrDefault(name,List.of());if(entries.isEmpty())continue;
      List<String> found=new ArrayList<>();for(Mapper m:entries){found.add(uri(m.path));direct.add(m.path);issues.addAll(m.issues);}
      Collections.sort(found);result.put(name,found);
    }return result;
  }
  Set<Path> referenced(Set<Path> direct,List<Map<String,Object>> issues){Set<Path> found=new TreeSet<>(direct);ArrayDeque<Path> q=new ArrayDeque<>(direct);
    while(!q.isEmpty()){Mapper from=all.get(q.removeFirst());if(from==null)continue;
      for(String target:from.refs.keySet()){
        List<Mapper> options=byNamespace.getOrDefault(target,List.of());
        if(options.isEmpty())issues.add(Support.diag("MAPPER_REFERENCE_UNRESOLVED",uri(from.path),"Referenced namespace not found: "+target));
        for(Mapper m:options)if(found.add(m.path)){q.add(m.path);issues.addAll(m.issues);}
      }
    }found.removeAll(direct);return found;
  }
}
