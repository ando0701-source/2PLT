package sourcescope;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.*;
import java.util.*;
import java.util.stream.*;
import java.time.OffsetDateTime;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public final class Main {
  static final String VERSION="0.3.6-jdk11-preview";
  private Main(){}
  public static void main(String[] args){try{run(args);}catch(Exception ex){System.err.println("ERROR: "+ex.getMessage());System.exit(1);}}
  static void run(String[] args) throws Exception{
    if(args.length==0 || args[0].equals("help") || args[0].equals("--help")){
      System.out.println("Source Scope "+VERSION+"\n"+
        "check (verify JDK 11+ and jdk.compiler)\n"+
        "analyze --root <project-folder> --out <new-output-folder> [--all | --entry <relative-java>] [--release 11] [--encoding UTF-8] [--classpath <jar-or-directory>]\n"+
        "lookup --out <completed-output-folder> --fqcn <java.fully.qualified.Name>");return;
    }
    String cmd=args[0];
    if(cmd.equals("check")){if(args.length!=1)throw new IllegalArgumentException("check takes no arguments");checkRuntime();return;}
    Map<String,String> options=new HashMap<>();
    for(int i=1;i<args.length;i++){
      if(args[i].equals("--all")){options.put("--all","true");continue;}
      if(!Set.of("--root","--out","--entry","--release","--encoding","--fqcn","--classpath").contains(args[i]) || i+1>=args.length)
        throw new IllegalArgumentException("Unknown or missing option: "+args[i]);
      String key=args[i++];if(options.put(key,args[i])!=null)throw new IllegalArgumentException("Repeated option: "+key);
    }
    if(cmd.equals("lookup")){lookup(options);return;}
    if(!cmd.equals("analyze"))throw new IllegalArgumentException("Unknown command: "+cmd);
    checkRuntime();
    analyze(options);
  }
  static void checkRuntime() throws IOException {
    int version=Runtime.version().feature();
    if(version<11)throw new IOException("JDK 11 or newer is required (current Java: "+version+")");
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    if(compiler==null)throw new IOException("A full JDK with the jdk.compiler module is required for analysis (JRE only is not sufficient)");
    System.out.println("JDK_OK: Java="+System.getProperty("java.version")+
      " VM="+System.getProperty("java.vm.name")+" Compiler="+compiler.getClass().getName());
  }
  static void lookup(Map<String,String> args) throws IOException{
    Path root=Paths.get(require(args,"--out")).toAbsolutePath().normalize();String fqcn=require(args,"--fqcn");
    Path index=root.resolve("fqcn-index.json");if(!Files.isRegularFile(index))throw new IOException("Index is missing: "+index);
    Map<String,Object> entries=Json.object(Json.parse(Files.readString(index,StandardCharsets.UTF_8)));
    Object matches=entries.get(fqcn);if(matches==null){System.out.println("NOT FOUND: "+fqcn);return;}
    System.out.println(Json.stringify(Json.row("fqcn",fqcn,"entries",matches)));
  }
  private static String require(Map<String,String> args,String key){String value=args.get(key);if(value==null || value.isBlank())throw new IllegalArgumentException("Required: "+key);return value;}
  static void analyze(Map<String,String> args) throws Exception{
    Path root=Paths.get(require(args,"--root")).toRealPath();if(!Files.isDirectory(root))throw new IOException("Not directory: "+root);
    Path suppliedOut=Paths.get(require(args,"--out")).toAbsolutePath().normalize();
    if(!Files.isDirectory(suppliedOut.getParent()))throw new IOException("Create output parent folder first: "+suppliedOut.getParent());
    Path finalOut=suppliedOut.getParent().toRealPath().resolve(suppliedOut.getFileName());
    if(finalOut.startsWith(root)||root.startsWith(finalOut))throw new IOException("Output must be outside source tree and cannot be its ancestor");
    if(Files.exists(finalOut))throw new IOException("Output folder already exists; use a new folder: "+finalOut);
    Path out=finalOut.resolveSibling(finalOut.getFileName().toString()+".building");
    if(Files.exists(out))throw new IOException("Incomplete previous run exists: "+out+". Remove it after confirming no run is active.");
    int release=Integer.parseInt(args.getOrDefault("--release","11"));
    int runtimeRelease=Runtime.version().feature();
    if(release<8 || release>runtimeRelease)throw new IOException("--release "+release+
      " is unavailable on this JDK "+runtimeRelease+"; choose a version from 8 to "+runtimeRelease+
      " (or run on a newer JDK to analyze newer Java sources)");
    String encoding=args.getOrDefault("--encoding","UTF-8");Charset.forName(encoding);
    List<Path> cp=new ArrayList<>();if(args.containsKey("--classpath")){
      for(String item:args.get("--classpath").split(java.io.File.pathSeparator)){
        Path file=Paths.get(item).toRealPath();if(!Files.isDirectory(file) && !Files.isRegularFile(file))throw new IOException("Classpath path missing: "+file);cp.add(file);
      }
    }
    Files.createDirectories(out);
    DiagnosticsReport diagnosticsReport=new DiagnosticsReport();
    PrintStream originalOut=System.out,originalErr=System.err;
    try(OutputStream sink=Files.newOutputStream(out.resolve("execution.log"),StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
        PrintStream loggedOut=new PrintStream(new TeeOutputStream(originalOut,sink),true,"UTF-8");
        PrintStream loggedErr=new PrintStream(new TeeOutputStream(originalErr,sink),true,"UTF-8")){
      System.setOut(loggedOut);System.setErr(loggedErr);
      try {
        System.out.println("RUN_STARTED: "+OffsetDateTime.now()+" tool="+VERSION);
    System.out.println("Source Scope "+VERSION+"  root: "+root);
    Set<Path> exclude=Set.of(out);
    List<Path> java=Support.files(root,".java",exclude),pom=Support.files(root,"pom.xml",exclude),xml=Support.files(root,".xml",exclude);
    xml.removeIf(x->x.getFileName().toString().equals("pom.xml"));
    System.out.println("Input: Java="+java.size()+" POM="+pom.size()+" XML candidates="+xml.size());
    if(java.isEmpty())throw new IOException("Java files not found");
    List<Path> entries=new ArrayList<>();
    if(args.containsKey("--entry")){
      Path e=root.resolve(args.get("--entry")).normalize();e=Support.inside(root,e);
      if(!java.contains(e))throw new IOException("Entry not a scanned Java source: "+e);entries.add(e);
    }else entries.addAll(java);
    long started=System.nanoTime();
    PomGraph poms=new PomGraph(root,pom);
    System.out.println("Indexing available JAR files and matching Maven dependencies...");
    JarCatalog jarCatalog=new JarCatalog(root,poms);
    poms.resolveJars(jarCatalog);
    jarCatalog.verifyClassCollisions();
    jarCatalog.writeReports(out);
    for(Map<String,Object> d:jarCatalog.globalIssues)
      diagnosticsReport.global("JAR",String.valueOf(d.get("severity")),String.valueOf(d.get("code")),
        String.valueOf(d.get("source_uri")),String.valueOf(d.get("message")));
    JavaGraph graph=new JavaGraph(root,poms,encoding,release,cp);
    System.out.println("Indexing Java declarations...");graph.index(java);
    System.out.println("Resolving Java symbols (offline; no build execution)...");graph.analyze(java);
    System.out.println("Indexing MyBatis Mapper XML...");MapperGraph mapper=new MapperGraph(root,xml);
    for(var bad:poms.invalidPoms.entrySet())
      diagnosticsReport.global("POM","POM_XML_INVALID",Support.uri(root,bad.getKey()),bad.getValue());
    for(Map<String,Object> bad:mapper.inputIssues)
      diagnosticsReport.global("XML",String.valueOf(bad.get("code")),
        String.valueOf(bad.get("source_uri")),String.valueOf(bad.get("message")));
    System.out.println("Hashing source inputs (read-only)...");
    StringBuilder fingerprint=new StringBuilder();
    long hashStarted=System.nanoTime();int hashed=0,totalInputs=java.size()+pom.size()+xml.size()+jarCatalog.jars.size();
    for(List<Path> kind:List.of(java,pom,xml))for(Path p:kind){
      fingerprint.append(Support.uri(root,p)).append(':').append(Support.hash(Files.readAllBytes(p))).append('\n');
      hashed++;
      if(hashed%1000==0 || hashed==totalInputs)System.out.println("  Input hashing: "+hashed+" / "+totalInputs+
        " ("+percent(hashed,totalInputs)+"%) elapsed="+duration(hashStarted));
    }
    for(JarCatalog.JarInfo j:jarCatalog.jars){
      fingerprint.append(j.uri).append(':').append(Support.hashFile(j.path)).append('\n');hashed++;
      if(hashed%1000==0 || hashed==totalInputs)System.out.println("  Input hashing: "+hashed+" / "+totalInputs+
        " ("+percent(hashed,totalInputs)+"%) elapsed="+duration(hashStarted));
    }
    String inputHash=Support.hash(fingerprint.toString());
    String configHash=Support.hash("root="+root+";release="+release+";encoding="+encoding+
      ";classpath="+cp+";adoptedJars="+jarCatalog.consumed.stream().map(p->Support.uri(root,p)).sorted().collect(Collectors.joining(";"))
      +";internalPackages="+String.join(";",jarCatalog.internalPrefixes));
    int incomplete1=0,incomplete2=0,maxFiles=0;long filesSum=0,maxJson=0;int count=0;
    long outputStarted=System.nanoTime();
    TreeMap<String,Object> fqcnIndex=new TreeMap<>();
    Support.write(out.resolve("run-report.json"),Json.row("state","IN_PROGRESS","tool_version",VERSION));
    for(Path entry:entries){String uri=Support.uri(root,entry);
      TreeSet<Path> closure=graph.closure(entry);
      TreeMap<String,String> sources=new TreeMap<>();TreeSet<String> additional=new TreeSet<>();
      TreeSet<String> names=new TreeSet<>();
      for(Path p:closure){Set<String> declared=graph.declarations.getOrDefault(p,Set.of());
        if(declared.isEmpty())additional.add(Support.uri(root,p));
        for(String fqcn:declared){if(graph.byFqcn.getOrDefault(fqcn,Set.of()).size()>1)continue;
          sources.put(fqcn,Support.uri(root,p));names.add(fqcn);}
      }
      List<Map<String,Object>> d1=new ArrayList<>(graph.closureIssues(closure));d1.addAll(poms.diagnostics(poms.owner(entry)));
      for(Path p:closure)d1.addAll(poms.invalidFor(p));
      d1=unique(d1);
      diagnosticsReport.affected("layer1",d1);
      String s1=d1.isEmpty()?"RESOLVED":"INCOMPLETE";if(!s1.equals("RESOLVED"))incomplete1++;
      List<String> entryNames=new ArrayList<>(graph.declarations.getOrDefault(entry,Set.of()));
      Map<String,Object> p1=Json.row("tool_version",VERSION,"source_set_id",sourceSet(poms,entry),"java_release",javaRelease(poms,entry,release),
        "configuration_sha256",configHash,"input_fingerprint_sha256",inputHash);
      // Keep a readable, collision-free hierarchy matching the original source path.
      // Fall back to a short hashed path when Windows path length would be excessive.
      String id=entryJsonPath(root,entry,out);
      Map<String,Object> m1=Json.row("schema_version","1.0","layer","compile","source_root_uri",Support.rootUri(root),
        "entry",Json.row("uri",uri,"fqcn",entryNames),"resolution",Json.row("status",s1,"build_verification","NOT_RUN"),
        "sources",sources,"additional_source_uris",new ArrayList<>(additional),"unresolved",d1,"provenance",p1,
        "summary",Json.row("source_file_count",closure.size(),"declared_fqcn_count",sources.size(),"unresolved_count",d1.size()));
      Path l1=out.resolve("layer1").resolve(id);Support.write(l1,m1);maxJson=Math.max(maxJson,Files.size(l1));
      List<Map<String,Object>> d2=new ArrayList<>();if(!s1.equals("RESOLVED"))d2.add(Support.diag("LAYER1_INCOMPLETE",uri,"Layer 1 has incomplete information"));
      Set<Path> direct=new HashSet<>();Map<String,List<String>> mappers=mapper.mappers(names,direct,d2);
      Set<Path> indirect=mapper.referenced(direct,d2);List<String> extraXml=indirect.stream().map(mapper::uri).sorted().collect(Collectors.toList());
      List<String> pomsRelated=poms.related(closure);d2.addAll(poms.diagnostics(poms.owner(entry)));d2=unique(d2);
      // LAYER1_INCOMPLETE is a per-entry consequence, not a separate root cause.
      // Keep it in layer2 JSON but do not create thousands of duplicate CSV rows.
      List<Map<String,Object>> layer2RootCauses=new ArrayList<>();
      for(Map<String,Object> d:d2)
        if(!"LAYER1_INCOMPLETE".equals(d.get("code")))layer2RootCauses.add(d);
      diagnosticsReport.affected("layer2",layer2RootCauses);
      String s2=d2.isEmpty()?"RESOLVED":"INCOMPLETE";if(!s2.equals("RESOLVED"))incomplete2++;
      Map<String,Object> m2=Json.row("schema_version","1.0","layer","module_mapper","source_root_uri",Support.rootUri(root),
        "entry",Json.row("uri",uri,"fqcn",entryNames),"resolution",Json.row("status",s2,"layer1_status",s1),
        "poms",pomsRelated,"mappers",mappers,"additional_mapper_uris",extraXml,"unresolved",d2,
        "provenance",Json.row("tool_version",VERSION,"source_set_id",sourceSet(poms,entry),
          "configuration_sha256",configHash,"input_fingerprint_sha256",inputHash,"layer1_input_fingerprint_sha256",inputHash),
        "summary",Json.row("pom_count",pomsRelated.size(),"mapper_xml_count",direct.size()+indirect.size(),"unresolved_count",d2.size()));
      Support.write(out.resolve("layer2").resolve(id),m2);
      Map<String,Object> link=Json.row("entry_uri",uri,"layer1","layer1/"+id,"layer2","layer2/"+id);
      for(String name:entryNames){List<Object> paths;
        if(!fqcnIndex.containsKey(name)){paths=new ArrayList<>();fqcnIndex.put(name,paths);}else paths=(List<Object>)fqcnIndex.get(name);
        paths.add(link);
      }
      count++;filesSum+=closure.size();maxFiles=Math.max(maxFiles,closure.size());
      if(count%100==0 || count==entries.size())System.out.println(
        "  JSON output: "+count+" / "+entries.size()+" ("+percent(count,entries.size())+"%)"
          +" elapsed="+duration(outputStarted));
    }
    System.out.println("  JSON output: writing FQCN indexes...");
    Support.write(out.resolve("fqcn-index.json"),fqcnIndex);
    int lookupFiles=0;long lookupStarted=System.nanoTime();int lookupsDone=0;
    System.out.println("  Lookup output: 0 / "+fqcnIndex.size());
    for(var item:fqcnIndex.entrySet()){
      String fqcn=item.getKey();String path=fqcn.replace('.','/')+".json";
      try{Path target=out.resolve("lookup").resolve(path).normalize();
        if(!target.startsWith(out.resolve("lookup")) || target.toString().length()>235)continue;
        Support.write(target,Json.row("fqcn",fqcn,"entries",item.getValue()));lookupFiles++;
      }catch(IOException ex){System.err.println("WARN: Lookup shortcut not created for "+fqcn+": "+ex.getMessage());}
      lookupsDone++;
      if(lookupsDone%500==0||lookupsDone==fqcnIndex.size())System.out.println("  Lookup output: "+lookupsDone+" / "+fqcnIndex.size()+
        " ("+percent(lookupsDone,fqcnIndex.size())+"%) elapsed="+duration(lookupStarted));
    }
    diagnosticsReport.write(out.resolve("diagnostics.csv"));
    System.out.println("  Diagnostics: "+diagnosticsReport.uniqueCount()+" distinct causes written to diagnostics.csv");
    long elapsed=(System.nanoTime()-started)/1_000_000;
    Support.write(out.resolve("run-report.json"),Json.row("state","COMPLETE","tool_version",VERSION,
      "runtime_java_version",System.getProperty("java.version"),
      "runtime_vm_name",System.getProperty("java.vm.name"),
      "java_file_count",java.size(),"pom_file_count",pom.size(),"xml_candidate_count",xml.size(),
      "mapper_xml_count",mapper.all.size(),"jar_candidate_count",jarCatalog.jars.size(),
      "jar_adopted_count",jarCatalog.adopted(),"jar_duplicate_class_count",jarCatalog.duplicateClassCount,"entry_count",count,"layer1_incomplete_count",incomplete1,
      "layer2_incomplete_count",incomplete2,"max_source_file_count",maxFiles,
      "average_source_file_count",count==0?0:(double)filesSum/count,"max_layer1_json_bytes",maxJson,
      "javac_analysis_groups",graph.compilationGroups,"lookup_shortcut_count",lookupFiles,"elapsed_milliseconds",elapsed,
      "diagnostics_unique_count",diagnosticsReport.uniqueCount(),
      "input_fingerprint_sha256",inputHash));
        System.out.println("RUN_COMPLETE: "+OffsetDateTime.now()
          +" entries="+count+" layer1_incomplete="+incomplete1+" layer2_incomplete="+incomplete2);
      } catch(Exception ex) {
        System.err.println("RUN_FAILED: "+OffsetDateTime.now()+" "+ex);
        ex.printStackTrace(System.err);
        diagnosticsReport.global("EXECUTION","EXECUTION_FAILED","",ex.toString());
        try {diagnosticsReport.write(out.resolve("diagnostics.csv"));}
        catch(IOException logEx){System.err.println("WARN: Cannot save diagnostics.csv: "+logEx);}
        try {Support.write(out.resolve("run-report.json"),Json.row(
          "state","FAILED","tool_version",VERSION,"error",ex.toString(),
          "diagnostics_unique_count",diagnosticsReport.uniqueCount()));}
        catch(IOException reportEx){System.err.println("WARN: Cannot save failure report: "+reportEx);}
        throw ex;
      } finally {
        System.out.flush();System.err.flush();
        System.setOut(originalOut);System.setErr(originalErr);
      }
    }
    IOException finalizationError=null;
    System.out.println("Finalizing completed output directory...");
    for(int attempt=1;attempt<=5;attempt++){
      try {
        try{Files.move(out,finalOut,StandardCopyOption.ATOMIC_MOVE);}
        catch(AtomicMoveNotSupportedException e){Files.move(out,finalOut);}
        finalizationError=null;break;
      }catch(IOException ex){finalizationError=ex;
        System.err.println("  Finalization retry "+attempt+" / 5: "+ex.getMessage());
        if(attempt<5)try{Thread.sleep(2000L*attempt);}catch(InterruptedException interrupted){
          Thread.currentThread().interrupt();break;}
      }
    }
    if(finalizationError!=null){
      String note="FINALIZATION_PENDING: analysis COMPLETE, directory rename failed: "+finalizationError+"\n";
      try{Files.writeString(out.resolve("execution.log"),note,StandardCharsets.UTF_8,StandardOpenOption.APPEND);}catch(IOException ignored){}
      System.err.println("[FINALIZATION_PENDING] Analysis files are complete, but Windows could not rename the folder.");
      System.err.println("Close Explorer/Excel/editors and rename only after checking run-report.json state=COMPLETE.");
      System.err.println("Result remains in: "+out);
      throw new IOException("Result folder rename failed; preserved COMPLETE report in "+out,finalizationError);
    }
    System.out.println("COMPLETE: result folder ready: "+finalOut);
    System.out.println("Diagnostics: "+finalOut.resolve("diagnostics.csv"));
    System.out.println("Execution log: "+finalOut.resolve("execution.log"));
    System.out.println("FQCN index: "+finalOut.resolve("fqcn-index.json"));
  }
  static String entryJsonPath(Path root,Path entry,Path outputRoot) {
    Path relative=root.relativize(entry);
    String filename=relative.getFileName().toString();
    if(!filename.endsWith(".java"))throw new IllegalArgumentException("Not a Java source: "+entry);
    String jsonName=filename.substring(0,filename.length()-5)+".json";
    Path path=relative.getParent()==null?Paths.get(jsonName):relative.getParent().resolve(jsonName);
    // The output folder is first written as <name>.building. Keep space for Windows
    // path handling and for the temporary .part suffix added by Support.write().
    Path candidate=outputRoot.resolve("layer1").resolve(path).normalize();
    if(candidate.toString().length()+5>230 || path.toString().length()>170){
      String hash=Support.hash(Support.uri(root,entry));
      return "_long/"+hash.substring(0,2)+"/"+hash+".json";
    }
    return path.toString().replace('\\','/');
  }
  static int percent(int done,int total){return total==0?100:(int)((100L*done)/total);}
  static String duration(long started){long seconds=(System.nanoTime()-started)/1_000_000_000L;
    return String.format(Locale.ROOT,"%dm%02ds",seconds/60,seconds%60);}
  private static int javaRelease(PomGraph pg,Path entry,int fallback){PomGraph.Pom p=pg.owner(entry);
    if(p==null || p.release==null || p.release.isBlank())return fallback;
    String r=p.release.startsWith("1.")?p.release.substring(2):p.release;
    try{return Integer.parseInt(r);}catch(NumberFormatException e){return fallback;}
  }
  private static String sourceSet(PomGraph pg,Path entry){PomGraph.Pom p=pg.owner(entry);return p==null?"standalone":pg.uri(p);}
  private static List<Map<String,Object>> unique(List<Map<String,Object>> ds){TreeMap<String,Map<String,Object>> r=new TreeMap<>();
    for(Map<String,Object> d:ds){String key=d.get("code")+"|"+d.get("source_uri")+"|"+d.get("message");r.put(key,d);}return new ArrayList<>(r.values());}
}
