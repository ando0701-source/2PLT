# Source Scope Preprocessor v0.3.6-jdk11-preview

Javaソースの静的依存関係（第一層）とPOM・MyBatis Mapper XMLの関連情報（第二層）を、**Javaファイルの起点ごとに自己完結したJSON**へ事前生成する検証版です。

- **ソースからJARを作り直す方（任意）：** `00_ビルドする.bat` → `03_動作確認.bat`。通常の利用ではビルド不要です。
- **Windowsで初めて使う方：** `40_導入手順書.md` → `03_動作確認.bat` → `01_解析する.bat` → `50_利用手順書.md`。
- **生成済みJSONをAIが読む場合：** JDKやMavenは不要です。ただしJSONと対応するソースファイルを読める環境は必要です。
- **事前解析側：** **JDK 11以上（jdk-11.0.7.10-openj9対応を目標）**。Maven・Python・データベース・ネットワークは不要です。
- **注意：** 複雑なMaven実効モデル、コード生成、Mavenの複雑な外部依存解決、JPMSは未完成です。`INCOMPLETE`に注意してください。**26,000 Javaファイル規模の実機性能・厳密な網羅性は未検証**です。

**v0.3.6の追加:** プロジェクト内JARの検出、POMとの対応付けとコンパイル用JARの採用、内部パッケージに一致するJARの除外、`external-libraries.csv` と `external-library-violations.csv` の生成。`lookup`の進捗表示と、最終フォルダー名変更のリトライ・結果保全も追加。`examples/internal-packages.txt` を解析対象の `config/internal-packages.txt` へコピーしてパッケージを指定できます（任意）。

**v0.3.4の追加:** `diagnostics.csv`（未解決・警告を原因別に集約）、`execution.log`（進捗・エラーを継続記録）。同一原因が多くの起点に影響する場合は、CSVの `affected_entry_count` で影響起点数を確認できます。**配布ZIPの日本語ファイル名をUTF-8で正しく保存**する方式に修正しました。

**v0.3.3の変更:** `layer1` と `layer2` を元ソースのフォルダー構造に合わせて階層化。Java索引化・シンボル解決・ハッシュ計算・JSON出力の進捗表示を追加しました。**v0.3.2で修正した `01_解析する.bat` を正本に取り込んでいます**（内容は同一）。

## コマンド例

```text
java --add-modules jdk.compiler -Xmx4g -jar bin/source-scope.jar analyze --root C:\work\myproject --out C:\results\run-001 --all --release 11 --encoding UTF-8
java -jar bin/source-scope.jar lookup --out C:\results\run-001 --fqcn demo.App
```

`--all`は省略可能です。`--entry app/src/main/java/demo/App.java`で起点を1つに限定できます。

## JDK 11 / OpenJ9 の注意

- `bin/source-scope.jar` はJava 11用クラス形式（class major 55）で配布します。
- Windowsではインストール済みのJDK 11を使用できます。`JAVA_HOME` を設定した場合はそのJDKを優先します。
- `03_動作確認.bat` が JDK・コンパイラーの利用可否とサンプル解析を一度に検査します。
- 解析には**JDK本体**が必要です（JREだけでは不可）。既存のJDK 11 OpenJ9を利用できれば、新規インストールは不要です。
- 利用者から **OpenJ9 11.0.7でv0.3.1のサンプル動作確認 `[PASS]`、v0.3.2の解析起動成功**が報告されています。v0.3.4は開発環境JDK 21で検証済みですが、OpenJ9でのv0.3.4実行は未確認です。
- JDK 11でJava 17以降のソースを厳密解析することはできません。対象のJavaバージョンに対応するJDKを使用してください。

## 主な成果物

- `external-libraries.csv`: 発見したすべてのJARと採用・除外・保留の判定、POMの対応、理由。
- `external-library-violations.csv`: 設定した内部パッケージを含むJARと該当FQCNを一覧化。
- `diagnostics.csv`: 原因・ファイル・層ごとにまとめた未解決／警告一覧。UTF-8（BOM付き）でExcelから確認できます。問題がない場合は見出し行だけです。
- `execution.log`: 解析開始・進捗・警告・実行時エラーを文字として保存。
- `run-report.json`: 全体の完了状態。**`state=COMPLETE`を確認**してください。
- `lookup/jp/aaa/App.json`: FQCNから起点の第一層・第二層JSONを探す小さな索引。
- `fqcn-index.json`: 全FQCNと該当するJSONパス（同名型の複数候補も保持）。
- `layer1/app/src/main/java/demo/App.json`: 元ソース `app/src/main/java/demo/App.java` に対応。起点・FQCN→相対URI、未解決、件数。
- `layer2/app/src/main/java/demo/App.json`: 同じ起点の関連POM・Mapper XML、未解決。
- 元ソースのパスが長すぎる場合は `_long/<ハッシュ先頭2文字>/<SHA-256>.json` に格納し、`lookup` に実際の場所を記録します。

ソースコードと再ビルド手順は`src/`、`scripts/build.sh`にあります。

## v0.3.3の進捗表示例

```text
Java indexing: 500 / 26000 (1%) elapsed=0m45s
Java resolving: 1000 / 26000 (3%) elapsed=5m00s | current batch=0 file(s)
```

`Java resolving` の処理中は通常100ファイル以上進むごと、加えて**30秒ごと**に途中経過を表示します。`current batch` は現在コンパイラーで処理しているファイル数です。処理時間・メモリー量を改善した変更ではありません。最後の`COMPLETE`までは結果フォルダーを利用しないでください。

**解析中に中断した場合：** 処理が開始されていれば、`run-... .building` フォルダー内の `execution.log` を確認してください。通常の異常終了では `run-report.json` を `FAILED` にし、`diagnostics.csv` も保存します。強制終了時には一部のファイルが未作成のことがあります。出力先を作る前の入力エラーは画面だけに出る場合があります。

**旧バージョンの出力との互換性:** `lookup/*.json` と `fqcn-index.json` を使用する参照方法は同じです。JSONの場所は索引内の `layer1` / `layer2` が示す値を使用し、古いハッシュ名を決め打ちしないでください。実行中の旧バージョンの解析には影響しません。

## v0.3.5の変更（オプションのビルド）

`00_ビルドする.bat` を追加。インストール済みJDK 11以上の `javac` / `jar` を使用して、ソースからJava 11互換の実行JARを再生成します。ビルド中は `build/classes-00` と一時JARを使用し、**コンパイル・JAR作成・JDK検査が成功した場合だけ** `bin/source-scope.jar` を置換します。通常利用・初回導入では実行不要です。解析・JSON出力の仕様はv0.3.4から変更しません。

## v0.3.6 利用上の要点

- **既存の `01_解析する.bat` をそのまま使用できます。** POMが指定する外部JARが解析対象フォルダー内にあれば、採用できるものだけを自動的にクラスパスに設定します。
- **JARは自動実行しません。** JARエントリとメタデータを読み取るだけです。
- 社内パッケージは `config/internal-packages.txt` で1行1パッケージ指定。未設定では内部パッケージ保護を行えないため、CSV確認が重要です。
- 結果フォルダー名の変更だけ失敗した場合、`.building` 内に `run-report.json: state=COMPLETE` と完成済みデータを保持します。未確認の `.building` を完成扱いしないでください。
- 本番規模（約26,000 Java・2,130 POM・859 Mapper XML）では未検証のため、旧版の解析結果も保管してください。
