# Source Scope Preprocessor v0.3.1-jdk11-preview

Javaソースの静的依存関係（第一層）とPOM・MyBatis Mapper XMLの関連情報（第二層）を、**Javaファイルの起点ごとに自己完結したJSON**へ事前生成する検証版です。

- **Windowsで初めて使う方：** `40_導入手順書.md` → `03_動作確認.bat` → `01_解析する.bat` → `50_利用手順書.md`。
- **生成済みJSONをAIが読む場合：** JDKやMavenは不要です。ただしJSONと対応するソースファイルを読める環境は必要です。
- **事前解析側：** **JDK 11以上（jdk-11.0.7.10-openj9対応を目標）**。Maven・Python・データベース・ネットワークは不要です。
- **注意：** 複雑なMaven実効モデル、コード生成、外部JARの完全解決、JPMSは未完成です。`INCOMPLETE`に注意してください。**26,000 Javaファイル規模の実機性能・厳密な網羅性は未検証**です。

## コマンド例

```text
java --add-modules jdk.compiler -Xmx4g -jar bin/source-scope.jar analyze --root C:\work\myproject --out C:\results\run-001 --all --release 11 --encoding UTF-8
java -jar bin/source-scope.jar lookup --out C:\results\run-001 --fqcn demo.App
```

`--all`は省略可能です。`--entry app/src/main/java/demo/App.java`で起点を1つに限定できます。

## JDK 11 / OpenJ9 の注意

- `bin/source-scope.jar` はJava 11用クラス形式（class major 55）で配布します。
- Windowsではインストール済みのJDK 11を使用できます。`JAVA_HOME` を設定した場合はそのJDKを優先します。
- `03_動作確認.bat` が JDK・コンパイラーの利用可否とサンプル解析を一度に検査します。
- 解析には**JDK本体**が必要です（JREだけでは不可）。既存のJDK 11 OpenJ9を利用できれば、新規インストールは不要です。
- **JDK 11実機（OpenJ9 11.0.7）での確認は未完了**です。開発環境のJDK 21でJava 11互換バイトコードと解析動作を検証しています。
- JDK 11でJava 17以降のソースを厳密解析することはできません。対象のJavaバージョンに対応するJDKを使用してください。

## 主な成果物

- `run-report.json`: 全体の完了状態。**`state=COMPLETE`を確認**してください。
- `lookup/jp/aaa/App.json`: FQCNから起点の第一層・第二層JSONを探す小さな索引。
- `fqcn-index.json`: 全FQCNと該当するJSONパス（同名型の複数候補も保持）。
- `layer1/<ID>.json`: 起点・FQCN→相対URI、未解決、件数。
- `layer2/<ID>.json`: 関連POM・Mapper XML、未解決。

ソースコードと再ビルド手順は`src/`、`scripts/build.sh`にあります。
