@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
set "KIT=%~dp0"
set "JAVA_EXE=java"
set "JAVAC_EXE=javac"

rem Prefer a complete JDK from JAVA_HOME, if available.
if not defined JAVA_HOME goto CHECK_JDK
if not exist "%JAVA_HOME%\bin\java.exe" goto CHECK_JDK
if not exist "%JAVA_HOME%\bin\javac.exe" goto CHECK_JDK
set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
set "JAVAC_EXE=%JAVA_HOME%\bin\javac.exe"

:CHECK_JDK
"%JAVAC_EXE%" -version >nul 2>&1
if errorlevel 1 goto ERROR_JDK
"%JAVA_EXE%" --add-modules jdk.compiler -jar "%KIT%bin\source-scope.jar" check
if errorlevel 1 goto ERROR_COMPILER

echo ===========================================================
echo   Source Scope - Java source dependency analysis
echo ===========================================================
echo.
echo Enter the folder containing the Java project.
echo Tip: You can drag and drop the folder into this window.
set "SRC="
set /p "SRC=Project folder: "
set "SRC=%SRC:"=%"
if not defined SRC goto ERROR_EMPTY
if not exist "%SRC%\." goto ERROR_FOLDER

set "REL=11"
set /p "REL=Java version in your project [11]: "
if not defined REL set "REL=11"
set "ENC=UTF-8"
set /p "ENC=Source encoding [UTF-8] (MS932 for Shift-JIS): "
if not defined ENC set "ENC=UTF-8"

set "DEST=%USERPROFILE%\SourceScopeResults"
if not exist "%DEST%\." mkdir "%DEST%" 2>nul
if not exist "%DEST%\." goto ERROR_DEST

rem Timestamp is optional; if PowerShell is unavailable, use numeric IDs.
set "STAMP="
for /f "delims=" %%A in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss" 2^>nul') do set "STAMP=%%A"
if not defined STAMP set "STAMP=%RANDOM%_%RANDOM%"
set "OUT=%DEST%\run-%STAMP%-%RANDOM%"
if exist "%OUT%\." goto ERROR_OUT_EXISTS

echo.
echo Input folder: "%SRC%"
echo Output folder: "%OUT%"
echo Processing may take time for large projects. Keep this window open.
echo.
"%JAVA_EXE%" --add-modules jdk.compiler -Xmx4g -jar "%KIT%bin\source-scope.jar" analyze --root "%SRC%" --out "%OUT%" --all --release "%REL%" --encoding "%ENC%"
if errorlevel 1 goto ERROR_ANALYSIS

echo.
echo [DONE] Completed result folder:
echo "%OUT%"
echo See 50_利用手順書.md for how to open the JSON.
pause
exit /b 0

:ERROR_JDK
echo.
echo [STOP] JDK 11 or newer is needed to create analysis JSON.
echo Use your installed JDK 11 including OpenJ9. Set JAVA_HOME if needed.
echo Java is not required later for reading generated JSON.
goto FAIL

:ERROR_COMPILER
echo.
echo [STOP] JDK 11 or newer with the compiler module is required.
goto FAIL

:ERROR_EMPTY
echo.
echo [STOP] Project folder was not entered.
goto FAIL

:ERROR_FOLDER
echo.
echo [STOP] Folder does not exist:
echo "%SRC%"
goto FAIL

:ERROR_DEST
echo.
echo [STOP] Could not create the output parent folder:
echo "%DEST%"
goto FAIL

:ERROR_OUT_EXISTS
echo.
echo [STOP] Output folder already exists. Run again to choose a new name.
goto FAIL

:ERROR_ANALYSIS
echo.
echo [STOP] Analysis failed. See the ERROR message above.
echo Do not use a .building folder as a completed result.
goto FAIL

:FAIL
pause
exit /b 1
