package sourcescope;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.*;
import java.util.*;
import java.util.stream.*;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public final class Main {
  static final String VERSION="0.3.1-jdk11-preview";
  private Main(){}
  public static void main(String[] args){try{run(args);}catch(Exception ex){System.err.println("ERROR: "+ex.getMessage());System.exit(1);}}
  static void run(String[] args) throws Exception{
    if(args.length==0 || args[0].equals("help") || args[0].equals("--help")){
      System.out.println("Source Scope "+VERSION+"\n"+
        "check (verify JDK 11+ and jdk.compiler)\n"+
        "analyze --root <project-folder> --out <new-output-folder> [--all | --entry <relative-java>] [--release 11] [--encoding UTF-8] [--classpath <jar-or-directory>]\n"+
        "lookup --out <completed-output-folder> --fqcn <java.fully.qualified.Name>");return;
    }
    String cmd=args[0];
    if(cmd.equals("check")){if(args.length!=1)throw new IllegalArgumentException("check takes no arguments");checkRuntime();return;}
    Map<String,String> options=new HashMap<>();
    for(int i=1;i<args.length;i++){
      if(args[i].equals("--all")){options.put("--all","true");continue;}
      if(!Set.of("--root","--out","--entry","--release","--encoding","--fqcn","--classpath").contains(args[i]) || i+1>=args.length)
        throw new IllegalArgumentException("Unknown or missing option: "+args[i]);
      String key=args[i++];if(options.put(key,args[i])!=null)throw new IllegalArgumentException("Repeated option: "+key);
    }
    if(cmd.equals("lookup")){lookup(options);return;}
    if(!cmd.equals("analyze"))throw new IllegalArgumentException("Unknown command: "+cmd);
    checkRuntime();
    analyze(options);
  }
  static void checkRuntime() throws IOException {
    int version=Runtime.version().feature();
    if(version<11)throw new IOException("JDK 11 or newer is required (current Java: "+version+")");
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    if(compiler==null)throw new IOException("A full JDK with the jdk.compiler module is required for analysis (JRE only is not sufficient)");
    System.out.println("JDK_OK: Java="+System.getProperty("java.version")+
      " VM="+System.getProperty("java.vm.name")+" Compiler="+compiler.getClass().getName());
  }
  static void lookup(Map<String,String> args) throws IOException{
    Path root=Paths.get(require(args,"--out")).toAbsolutePath().normalize();String fqcn=require(args,"--fqcn");
    Path index=root.resolve("fqcn-index.json");if(!Files.isRegularFile(index))throw new IOException("Index is missing: "+index);
    Map<String,Object> entries=Json.object(Json.parse(Files.readString(index,StandardCharsets.UTF_8)));
    Object matches=entries.get(fqcn);if(matches==null){System.out.println("NOT FOUND: "+fqcn);return;}
    System.out.println(Json.stringify(Json.row("fqcn",fqcn,"entries",matches)));
  }
  private static String require(Map<String,String> args,String key){String value=args.get(key);if(value==null || value.isBlank())throw new IllegalArgumentException("Required: "+key);return value;}
  static void analyze(Map<String,String> args) throws Exception{
    Path root=Paths.get(require(args,"--root")).toRealPath();if(!Files.isDirectory(root))throw new IOException("Not directory: "+root);
    Path suppliedOut=Paths.get(require(args,"--out")).toAbsolutePath().normalize();
    if(!Files.isDirectory(suppliedOut.getParent()))throw new IOException("Create output parent folder first: "+suppliedOut.getParent());
    Path finalOut=suppliedOut.getParent().toRealPath().resolve(suppliedOut.getFileName());
    if(finalOut.startsWith(root)||root.startsWith(finalOut))throw new IOException("Output must be outside source tree and cannot be its ancestor");
    if(Files.exists(finalOut))throw new IOException("Output folder already exists; use a new folder: "+finalOut);
    Path out=finalOut.resolveSibling(finalOut.getFileName().toString()+".building");
    if(Files.exists(out))throw new IOException("Incomplete previous run exists: "+out+". Remove it after confirming no run is active.");
    int release=Integer.parseInt(args.getOrDefault("--release","11"));
    int runtimeRelease=Runtime.version().feature();
    if(release<8 || release>runtimeRelease)throw new IOException("--release "+release+
      " is unavailable on this JDK "+runtimeRelease+"; choose a version from 8 to "+runtimeRelease+
      " (or run on a newer JDK to analyze newer Java sources)");
    String encoding=args.getOrDefault("--encoding","UTF-8");Charset.forName(encoding);
    List<Path> cp=new ArrayList<>();if(args.containsKey("--classpath")){
      for(String item:args.get("--classpath").split(java.io.File.pathSeparator)){
        Path file=Paths.get(item).toRealPath();if(!Files.isDirectory(file) && !Files.isRegularFile(file))throw new IOException("Classpath path missing: "+file);cp.add(file);
      }
    }
    System.out.println("Source Scope "+VERSION+"  root: "+root);
    Set<Path> exclude=Set.of(out);
    List<Path> java=Support.files(root,".java",exclude),pom=Support.files(root,"pom.xml",exclude),xml=Support.files(root,".xml",exclude);
    xml.removeIf(x->x.getFileName().toString().equals("pom.xml"));
    System.out.println("Input: Java="+java.size()+" POM="+pom.size()+" XML candidates="+xml.size());
    if(java.isEmpty())throw new IOException("Java files not found");
    List<Path> entries=new ArrayList<>();
    if(args.containsKey("--entry")){
      Path e=root.resolve(args.get("--entry")).normalize();e=Support.inside(root,e);
      if(!java.contains(e))throw new IOException("Entry not a scanned Java source: "+e);entries.add(e);
    }else entries.addAll(java);
    long started=System.nanoTime();
    PomGraph poms=new PomGraph(root,pom);
    JavaGraph graph=new JavaGraph(root,poms,encoding,release,cp);
    System.out.println("Indexing Java declarations...");graph.index(java);
    System.out.println("Resolving Java symbols (offline; no build execution)...");graph.analyze(java);
    System.out.println("Indexing MyBatis Mapper XML...");MapperGraph mapper=new MapperGraph(root,xml);
    StringBuilder fingerprint=new StringBuilder();
    for(Path p:java)fingerprint.append(Support.uri(root,p)).append(':').append(Support.hash(Files.readAllBytes(p))).append('\n');
    for(Path p:pom)fingerprint.append(Support.uri(root,p)).append(':').append(Support.hash(Files.readAllBytes(p))).append('\n');
    for(Path p:xml)fingerprint.append(Support.uri(root,p)).append(':').append(Support.hash(Files.readAllBytes(p))).append('\n');
    String inputHash=Support.hash(fingerprint.toString());
    String configHash=Support.hash("root="+root+";release="+release+";encoding="+encoding+";classpath="+cp);
    int incomplete1=0,incomplete2=0,maxFiles=0;long filesSum=0,maxJson=0;int count=0;
    TreeMap<String,Object> fqcnIndex=new TreeMap<>();
    Files.createDirectories(out);
    Support.write(out.resolve("run-report.json"),Json.row("state","IN_PROGRESS","tool_version",VERSION));
    for(Path entry:entries){String uri=Support.uri(root,entry);
      TreeSet<Path> closure=graph.closure(entry);
      TreeMap<String,String> sources=new TreeMap<>();TreeSet<String> additional=new TreeSet<>();
      TreeSet<String> names=new TreeSet<>();
      for(Path p:closure){Set<String> declared=graph.declarations.getOrDefault(p,Set.of());
        if(declared.isEmpty())additional.add(Support.uri(root,p));
        for(String fqcn:declared){if(graph.byFqcn.getOrDefault(fqcn,Set.of()).size()>1)continue;
          sources.put(fqcn,Support.uri(root,p));names.add(fqcn);}
      }
      List<Map<String,Object>> d1=new ArrayList<>(graph.closureIssues(closure));d1.addAll(poms.diagnostics(poms.owner(entry)));
      for(Path p:closure)d1.addAll(poms.invalidFor(p));
      d1=unique(d1);
      String s1=d1.isEmpty()?"RESOLVED":"INCOMPLETE";if(!s1.equals("RESOLVED"))incomplete1++;
      List<String> entryNames=new ArrayList<>(graph.declarations.getOrDefault(entry,Set.of()));
      Map<String,Object> p1=Json.row("tool_version",VERSION,"source_set_id",sourceSet(poms,entry),"java_release",javaRelease(poms,entry,release),
        "configuration_sha256",configHash,"input_fingerprint_sha256",inputHash);
      String id=Support.hash(uri).substring(0,24)+".json";
      Map<String,Object> m1=Json.row("schema_version","1.0","layer","compile","source_root_uri",Support.rootUri(root),
        "entry",Json.row("uri",uri,"fqcn",entryNames),"resolution",Json.row("status",s1,"build_verification","NOT_RUN"),
        "sources",sources,"additional_source_uris",new ArrayList<>(additional),"unresolved",d1,"provenance",p1,
        "summary",Json.row("source_file_count",closure.size(),"declared_fqcn_count",sources.size(),"unresolved_count",d1.size()));
      Path l1=out.resolve("layer1").resolve(id);Support.write(l1,m1);maxJson=Math.max(maxJson,Files.size(l1));
      List<Map<String,Object>> d2=new ArrayList<>();if(!s1.equals("RESOLVED"))d2.add(Support.diag("LAYER1_INCOMPLETE",uri,"Layer 1 has incomplete information"));
      Set<Path> direct=new HashSet<>();Map<String,List<String>> mappers=mapper.mappers(names,direct,d2);
      Set<Path> indirect=mapper.referenced(direct,d2);List<String> extraXml=indirect.stream().map(mapper::uri).sorted().collect(Collectors.toList());
      List<String> pomsRelated=poms.related(closure);d2.addAll(poms.diagnostics(poms.owner(entry)));d2=unique(d2);
      String s2=d2.isEmpty()?"RESOLVED":"INCOMPLETE";if(!s2.equals("RESOLVED"))incomplete2++;
      Map<String,Object> m2=Json.row("schema_version","1.0","layer","module_mapper","source_root_uri",Support.rootUri(root),
        "entry",Json.row("uri",uri,"fqcn",entryNames),"resolution",Json.row("status",s2,"layer1_status",s1),
        "poms",pomsRelated,"mappers",mappers,"additional_mapper_uris",extraXml,"unresolved",d2,
        "provenance",Json.row("tool_version",VERSION,"source_set_id",sourceSet(poms,entry),
          "configuration_sha256",configHash,"input_fingerprint_sha256",inputHash,"layer1_input_fingerprint_sha256",inputHash),
        "summary",Json.row("pom_count",pomsRelated.size(),"mapper_xml_count",direct.size()+indirect.size(),"unresolved_count",d2.size()));
      Support.write(out.resolve("layer2").resolve(id),m2);
      Map<String,Object> link=Json.row("entry_uri",uri,"layer1","layer1/"+id,"layer2","layer2/"+id);
      for(String name:entryNames){List<Object> paths;
        if(!fqcnIndex.containsKey(name)){paths=new ArrayList<>();fqcnIndex.put(name,paths);}else paths=(List<Object>)fqcnIndex.get(name);
        paths.add(link);
      }
      count++;filesSum+=closure.size();maxFiles=Math.max(maxFiles,closure.size());
      if(count%1000==0)System.out.println("  JSON entries: "+count+" / "+entries.size());
    }
    Support.write(out.resolve("fqcn-index.json"),fqcnIndex);
    int lookupFiles=0;for(var item:fqcnIndex.entrySet()){
      String fqcn=item.getKey();String path=fqcn.replace('.','/')+".json";
      try{Path target=out.resolve("lookup").resolve(path).normalize();
        if(!target.startsWith(out.resolve("lookup")) || target.toString().length()>235)continue;
        Support.write(target,Json.row("fqcn",fqcn,"entries",item.getValue()));lookupFiles++;
      }catch(IOException ex){System.err.println("WARN: Lookup shortcut not created for "+fqcn+": "+ex.getMessage());}
    }
    long elapsed=(System.nanoTime()-started)/1_000_000;
    Support.write(out.resolve("run-report.json"),Json.row("state","COMPLETE","tool_version",VERSION,
      "runtime_java_version",System.getProperty("java.version"),
      "runtime_vm_name",System.getProperty("java.vm.name"),
      "java_file_count",java.size(),"pom_file_count",pom.size(),"xml_candidate_count",xml.size(),
      "mapper_xml_count",mapper.all.size(),"entry_count",count,"layer1_incomplete_count",incomplete1,
      "layer2_incomplete_count",incomplete2,"max_source_file_count",maxFiles,
      "average_source_file_count",count==0?0:(double)filesSum/count,"max_layer1_json_bytes",maxJson,
      "javac_analysis_groups",graph.compilationGroups,"lookup_shortcut_count",lookupFiles,"elapsed_milliseconds",elapsed,
      "input_fingerprint_sha256",inputHash));
    try{Files.move(out,finalOut,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(out,finalOut);}
    System.out.println("COMPLETE: "+count+" entries. Layer1 incomplete="+incomplete1+", Layer2 incomplete="+incomplete2);
    System.out.println("Output: "+finalOut);
    System.out.println("FQCN index: "+finalOut.resolve("fqcn-index.json"));
  }
  private static int javaRelease(PomGraph pg,Path entry,int fallback){PomGraph.Pom p=pg.owner(entry);
    if(p==null || p.release==null || p.release.isBlank())return fallback;
    String r=p.release.startsWith("1.")?p.release.substring(2):p.release;
    try{return Integer.parseInt(r);}catch(NumberFormatException e){return fallback;}
  }
  private static String sourceSet(PomGraph pg,Path entry){PomGraph.Pom p=pg.owner(entry);return p==null?"standalone":pg.uri(p);}
  private static List<Map<String,Object>> unique(List<Map<String,Object>> ds){TreeMap<String,Map<String,Object>> r=new TreeMap<>();
    for(Map<String,Object> d:ds){String key=d.get("code")+"|"+d.get("source_uri")+"|"+d.get("message");r.put(key,d);}return new ArrayList<>(r.values());}
}
