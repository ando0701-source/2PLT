package sourcescope;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.*;
import java.util.*;
import javax.tools.*;
import javax.lang.model.element.*;
import javax.lang.model.util.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

final class JavaGraph {
  final Path root; final PomGraph poms; final String encoding;final int release;final List<Path> classpath;
  final TreeMap<Path,Set<String>> declarations=new TreeMap<>();
  final Map<String,Set<Path>> byFqcn=new TreeMap<>();
  final Map<Path,Set<Path>> edges=new HashMap<>();
  final Map<Path,List<Map<String,Object>>> issues=new HashMap<>();
  final Map<Path,Path> sourceRoots=new HashMap<>();
  int compilationGroups=0;
  JavaGraph(Path root,PomGraph poms,String encoding,int release,List<Path> cp){this.root=root;this.poms=poms;this.encoding=encoding;this.release=release;this.classpath=cp;}
  void issue(Path file,String code,String message){issues.computeIfAbsent(file,k->new ArrayList<>()).add(Support.diag(code,Support.uri(root,file),message));}
  void index(List<Path> paths) throws IOException {
    // Parsing only: avoids retaining 26,000 ASTs in memory.
    for(int i=0;i<paths.size();i+=100){List<Path> batch=paths.subList(i,Math.min(paths.size(),i+100));
      JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();if(compiler==null)throw new IOException("JDK required (javac not available)");
      DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
      try(StandardJavaFileManager mgr=compiler.getStandardFileManager(diagnostics,Locale.ROOT,Charset.forName(encoding))){
        var units=mgr.getJavaFileObjectsFromPaths(batch);
        JavacTask task=(JavacTask)compiler.getTask(null,mgr,diagnostics,List.of("-proc:none"),null,units);
        try{for(CompilationUnitTree tree:task.parse()){
          Path path=Paths.get(tree.getSourceFile().toUri()).toRealPath();
          String pkg=tree.getPackageName()==null?"":tree.getPackageName().toString();
          TreeSet<String> names=new TreeSet<>();
          for(Tree decl:tree.getTypeDecls()) if(decl instanceof ClassTree)collectTypes((ClassTree)decl,pkg,names);
          declarations.put(path,names);
          Path src=findSourceRoot(path);if(src!=null)sourceRoots.put(path,src);
          for(String name:names)byFqcn.computeIfAbsent(name,k->new LinkedHashSet<>()).add(path);
        }}catch(RuntimeException ex){throw new IOException("Java parse error: "+ex.getMessage(),ex);}
      }
      for(var d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR && d.getSource()!=null){
        try{Path p=Paths.get(d.getSource().toUri()).toRealPath();issue(p,"JAVA_SYNTAX_ERROR","Line "+d.getLineNumber()+": "+d.getMessage(Locale.ROOT));}catch(Exception ignored){}
      }
    }
    for(var e:byFqcn.entrySet())if(e.getValue().size()>1)
      for(Path path:e.getValue())issue(path,"FQCN_COLLISION","Duplicate FQCN in project: "+e.getKey());
  }
  private void collectTypes(ClassTree c,String prefix,Set<String> target){String n=c.getSimpleName().toString();if(n.isEmpty())return;
    String fqcn=prefix.isEmpty()?n:prefix+"."+n;target.add(fqcn);
    for(Tree t:c.getMembers())if(t instanceof ClassTree)collectTypes((ClassTree)t,fqcn,target);
  }
  private Path findSourceRoot(Path path){PomGraph.Pom owner=poms.owner(path);
    if(owner!=null){Path src=owner.path.getParent().resolve(owner.sourceDir).normalize();if(path.startsWith(src))return src;}
    Path p=path.getParent();while(p!=null){if(p.getFileName()!=null && p.getFileName().toString().equals("java") &&
      p.getParent()!=null && p.getParent().getFileName()!=null && p.getParent().getFileName().toString().equals("main"))return p;p=p.getParent();}
    return root;
  }
  void analyze(List<Path> files) throws IOException {
    Map<String,List<Path>> groups=new TreeMap<>();
    for(Path file:files){PomGraph.Pom p=poms.owner(file);String k=p==null?"__NO_POM__":Support.uri(root,p.path);
      groups.computeIfAbsent(k,x->new ArrayList<>()).add(file);}
    int done=0;
    for(List<Path> group:groups.values()){
      // Splitting large modules bounds AST memory. Sourcepath still provides context.
      for(int i=0;i<group.size();i+=80){ analyzeGroup(group.subList(i,Math.min(i+80,group.size())));compilationGroups++; }
      done+=group.size(); if(done%1000 < group.size())System.out.println("  Java attributes: "+done+" / "+files.size());
    }
  }
  private void analyzeGroup(List<Path> group) throws IOException {
    if(group.isEmpty())return;
    PomGraph.Pom owner=poms.owner(group.get(0));
    LinkedHashSet<Path> sourcePaths=new LinkedHashSet<>();
    for(PomGraph.Pom p:poms.visible(owner)){
      Path sr=p.path.getParent().resolve(p.sourceDir).normalize();if(Files.isDirectory(sr))sourcePaths.add(sr);
    }
    for(Path p:group){Path sr=sourceRoots.get(p);if(sr!=null && Files.isDirectory(sr))sourcePaths.add(sr);}
    int actualRelease=release; if(owner!=null && owner.release!=null && !owner.release.isBlank()){
      try{String r=owner.release.startsWith("1.")?owner.release.substring(2):owner.release;actualRelease=Integer.parseInt(r);}
      catch(NumberFormatException ex){for(Path f:group)issue(f,"POM_RELEASE_UNRESOLVED","Unsupported release value: "+owner.release);}
    }
    // A POM may request a Java language level newer than the installed JDK.
    // Do not silently mislabel that case as a complete dependency closure.
    if(actualRelease<8 || actualRelease>Runtime.version().feature()){
      for(Path f:group)issue(f,"JAVA_RELEASE_UNSUPPORTED",
        "Module requests Java release "+actualRelease+", but this JDK supports analysis releases 8.."+Runtime.version().feature());
      return;
    }
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
    try(StandardJavaFileManager mgr=compiler.getStandardFileManager(diagnostics,Locale.ROOT,Charset.forName(encoding))){
      if(!sourcePaths.isEmpty())mgr.setLocationFromPaths(StandardLocation.SOURCE_PATH,sourcePaths);
      if(!classpath.isEmpty())mgr.setLocationFromPaths(StandardLocation.CLASS_PATH,classpath);
      Iterable<? extends JavaFileObject> inputs=mgr.getJavaFileObjectsFromPaths(group);
      ArrayList<String> options=new ArrayList<>(List.of("-proc:none","-implicit:none","-Xprefer:source","--release",String.valueOf(actualRelease)));
      JavacTask task=(JavacTask)compiler.getTask(null,mgr,diagnostics,options,null,inputs);
      Iterable<? extends CompilationUnitTree> parsed=task.parse();
      try{task.analyze();}catch(RuntimeException e){for(Path p:group)issue(p,"JAVAC_ANALYZE_ERROR",e.toString());}
      Trees trees=Trees.instance(task);
      for(CompilationUnitTree unit:parsed){Path from;
        try{from=Paths.get(unit.getSourceFile().toUri()).toRealPath();}catch(Exception e){continue;}
        edges.computeIfAbsent(from,k->new TreeSet<>());
        new TreePathScanner<Void,Void>(){
          private void add(Element symbol){if(symbol==null)return;Element e=symbol;
            while(e!=null && !(e instanceof TypeElement))e=e.getEnclosingElement();
            if(!(e instanceof TypeElement))return;
            String fqcn=((TypeElement)e).getQualifiedName().toString();if(fqcn.isEmpty())return;
            Set<Path> possibles=byFqcn.getOrDefault(fqcn,Set.of());if(possibles.isEmpty())return;
            Path bound=null;TreePath tp=trees.getPath(e);
            if(tp!=null && tp.getCompilationUnit()!=null && tp.getCompilationUnit().getSourceFile()!=null){
              try{Path src=Paths.get(tp.getCompilationUnit().getSourceFile().toUri()).toRealPath();if(possibles.contains(src))bound=src;}
              catch(Exception ignored){}
            }
            if(bound==null && possibles.size()==1 && classpath.isEmpty()){
              // Bound symbol was verified by javac, but source origin may be loaded implicitly.
              Path candidate=possibles.iterator().next();if(sourcePaths.stream().anyMatch(candidate::startsWith))bound=candidate;
            }
            if(bound==null && possibles.size()>1)issue(from,"FQCN_COLLISION","Ambiguous source binding: "+fqcn);
            if(bound!=null && !bound.equals(from))edges.get(from).add(bound);
          }
          @Override public Void visitIdentifier(IdentifierTree n,Void x){add(trees.getElement(getCurrentPath()));return super.visitIdentifier(n,x);}
          @Override public Void visitMemberSelect(MemberSelectTree n,Void x){add(trees.getElement(getCurrentPath()));return super.visitMemberSelect(n,x);}
          @Override public Void visitMemberReference(MemberReferenceTree n,Void x){add(trees.getElement(getCurrentPath()));return super.visitMemberReference(n,x);}
        }.scan(unit,null);
      }
    }catch(RuntimeException ex){for(Path p:group)issue(p,"JAVAC_CONTEXT_FAILED",ex.toString());}
    for(Diagnostic<? extends JavaFileObject> d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR){
      if(d.getSource()==null){for(Path p:group)issue(p,"JAVAC_UNRESOLVED",d.getMessage(Locale.ROOT));continue;}
      try{Path p=Paths.get(d.getSource().toUri()).toRealPath();if(declarations.containsKey(p))issue(p,"JAVAC_UNRESOLVED","Line "+d.getLineNumber()+": "+d.getMessage(Locale.ROOT));}
      catch(Exception ignored){}
    }
  }
  TreeSet<Path> closure(Path entry){TreeSet<Path> visited=new TreeSet<>();ArrayDeque<Path> q=new ArrayDeque<>();q.add(entry);
    while(!q.isEmpty()){Path x=q.removeFirst();if(!visited.add(x))continue;
      for(Path next:edges.getOrDefault(x,Set.of()))if(!visited.contains(next))q.add(next);
    }return visited;
  }
  List<Map<String,Object>> closureIssues(Set<Path> paths){List<Map<String,Object>> list=new ArrayList<>();
    for(Path p:paths)list.addAll(issues.getOrDefault(p,List.of()));return list;
  }
}
