package sourcescope;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.net.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;

final class Support {
  private Support() {}
  static String hash(byte[] value) {
    try { byte[] digest = MessageDigest.getInstance("SHA-256").digest(value); StringBuilder s = new StringBuilder();
      for (byte b : digest) s.append(String.format(Locale.ROOT,"%02x", b & 255)); return s.toString();
    } catch (NoSuchAlgorithmException ex) { throw new IllegalStateException(ex); }
  }
  static String hash(String s) { return hash(s.getBytes(StandardCharsets.UTF_8)); }
  static String uri(Path root, Path file) {
    Path rel = root.relativize(file);
    StringBuilder r = new StringBuilder();
    for (Path part : rel) {
      if (r.length()>0) r.append('/');
      try { String encoded = new URI(null,null,"/"+part.toString(),null).getRawPath().substring(1); r.append(encoded); }
      catch (URISyntaxException ex) { throw new IllegalArgumentException(ex); }
    }
    return r.toString();
  }
  static Path inside(Path root, Path file) throws IOException {
    Path actual=file.toRealPath(); if (!actual.startsWith(root)) throw new IOException("PATH_OUTSIDE_ROOT: "+file);
    return actual;
  }
  static String rootUri(Path root) { String s=root.toUri().toASCIIString(); return s.endsWith("/")?s:s+"/"; }
  static List<Path> files(Path root, String suffix, Set<Path> exclude) throws IOException {
    ArrayList<Path> found=new ArrayList<>();
    Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
      @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attributes){
        if(!dir.equals(root) && (exclude.stream().anyMatch(dir::startsWith) || hasIgnoredFolder(root.relativize(dir))))
          return FileVisitResult.SKIP_SUBTREE;
        return FileVisitResult.CONTINUE;
      }
      @Override public FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attributes) throws IOException {
        if(Files.isRegularFile(file) && (suffix.equals("pom.xml")?file.getFileName().toString().equals("pom.xml")
            :file.getFileName().toString().endsWith(suffix))) found.add(inside(root,file));
        return FileVisitResult.CONTINUE;
      }
    });
    found.sort(Comparator.comparing(x -> uri(root,x))); return found;
  }
  private static boolean hasIgnoredFolder(Path rel) {
    for (Path p:rel) if (Set.of(".git", "target", "build", ".gradle", "node_modules", ".idea").contains(p.toString())) return true;
    return false;
  }
  static Document xml(Path file) throws IOException {
    try {
      DocumentBuilderFactory f=DocumentBuilderFactory.newInstance(); f.setNamespaceAware(true);
      f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
      f.setFeature("http://xml.org/sax/features/external-general-entities",false);
      f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
      f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);
      f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
      f.setXIncludeAware(false); f.setExpandEntityReferences(false);
      DocumentBuilder b=f.newDocumentBuilder();
      b.setEntityResolver((publicId,systemId)->new InputSource(new StringReader("")));
      b.setErrorHandler(new ErrorHandler() { public void warning(SAXParseException e) throws SAXException { throw e; }
        public void error(SAXParseException e) throws SAXException {throw e;}
        public void fatalError(SAXParseException e) throws SAXException {throw e;} });
      try (InputStream in=Files.newInputStream(file)) { Document d=b.parse(in); if (d.getDoctype()!=null && d.getDoctype().getInternalSubset()!=null && !d.getDoctype().getInternalSubset().trim().isEmpty()) throw new IOException("DTD internal subset is not supported"); return d; }
    } catch(Exception ex) { throw new IOException("XML_READ_ERROR: "+file+": "+ex.getMessage(),ex); }
  }
  static String name(Node n) { return n.getLocalName()==null?n.getNodeName():n.getLocalName(); }
  static Element child(Element e, String n) {if(e==null)return null; for(Node x=e.getFirstChild();x!=null;x=x.getNextSibling()) if(x instanceof Element && name(x).equals(n))return(Element)x; return null;}
  static List<Element> children(Element e, String n) { ArrayList<Element> r=new ArrayList<>(); if(e!=null)for(Node x=e.getFirstChild();x!=null;x=x.getNextSibling())if(x instanceof Element && (n==null||name(x).equals(n)))r.add((Element)x);return r; }
  static String text(Element e,String n,String fallback){Element x=child(e,n);return x==null?fallback:x.getTextContent().trim();}
  static Map<String,Object> diag(String code,String uri,String message){return Json.row("code",code,"severity","ERROR","source_uri",uri,"message",message);}
  static void write(Path file,Object value) throws IOException { Files.createDirectories(file.getParent());
    Path temp=file.resolveSibling(file.getFileName()+".part");Json.write(temp,value); try { Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
    catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);} }
}
