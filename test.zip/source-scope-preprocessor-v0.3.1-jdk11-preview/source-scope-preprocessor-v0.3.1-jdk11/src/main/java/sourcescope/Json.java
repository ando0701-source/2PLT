package sourcescope;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;

final class Json {
    private final String text;
    private int pos;

    private Json(String text) {
        this.text = text.startsWith("\ufeff") ? text.substring(1) : text;
    }

    static Object parse(String text) {
        Json parser = new Json(text);
        Object value = parser.value();
        parser.space();
        if (parser.pos != parser.text.length()) throw parser.error("Trailing content");
        return value;
    }

    static String read(Path path, Charset charset) throws IOException {
        return charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(Files.readAllBytes(path))).toString();
    }

    static void write(Path path, Object value) throws IOException {
        Files.write(path, stringify(value).getBytes(StandardCharsets.UTF_8));
    }

    static Map<String, Object> object(Object value) {
        if (!(value instanceof Map)) throw new IllegalArgumentException("Expected JSON object");
        Map<String, Object> result = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : ((Map<?, ?>)value).entrySet()) {
            if (!(entry.getKey() instanceof String)) throw new IllegalArgumentException("Expected string key");
            result.put((String)entry.getKey(), entry.getValue());
        }
        return result;
    }

    static List<Object> array(Object value) {
        if (!(value instanceof List)) throw new IllegalArgumentException("Expected JSON array");
        return new ArrayList<>((List<?>)value);
    }

    static String string(Object value) {
        if (!(value instanceof String)) throw new IllegalArgumentException("Expected JSON string");
        return (String)value;
    }

    static Map<String, Object> row(Object... pairs) {
        if (pairs.length % 2 != 0) throw new IllegalArgumentException("Unpaired object keys");
        Map<String, Object> result = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) result.put((String)pairs[i], pairs[i + 1]);
        return result;
    }

    static String stringify(Object value) {
        if (value == null) return "null";
        if (value instanceof String) return quote((String)value);
        if (value instanceof Boolean || value instanceof Number) return value.toString();
        StringJoiner result;
        if (value instanceof Map) {
            result = new StringJoiner(",", "{", "}");
            for (Map.Entry<?, ?> entry : ((Map<?, ?>)value).entrySet())
                result.add(quote((String)entry.getKey()) + ":" + stringify(entry.getValue()));
        } else if (value instanceof Collection) {
            result = new StringJoiner(",", "[", "]");
            for (Object item : (Collection<?>)value) result.add(stringify(item));
        } else throw new IllegalArgumentException("Unsupported JSON value: " + value.getClass());
        return result.toString();
    }

    private static String quote(String value) {
        StringBuilder out = new StringBuilder("\"");
        for (char c : value.toCharArray()) {
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 32) out.append(String.format(Locale.ROOT, "\\u%04x", (int)c));
                    else out.append(c);
            }
        }
        return out.append('"').toString();
    }

    private void space() {
        while (pos < text.length() && " \t\r\n".indexOf(text.charAt(pos)) >= 0) pos++;
    }

    private IllegalArgumentException error(String message) {
        return new IllegalArgumentException(message + " at JSON offset " + pos);
    }

    private char next() {
        if (pos >= text.length()) throw error("Unexpected end");
        return text.charAt(pos++);
    }

    private Object value() {
        space();
        char c = next();
        if (c == '"') return readString();
        if (c == '{') {
            Map<String, Object> result = new LinkedHashMap<>();
            space();
            if (pos < text.length() && text.charAt(pos) == '}') { pos++; return result; }
            while (true) {
                space();
                if (next() != '"') throw error("Expected object key");
                String key = readString();
                space();
                if (next() != ':') throw error("Expected colon");
                if (result.containsKey(key)) throw error("Duplicate key: " + key);
                result.put(key, value());
                space();
                c = next();
                if (c == '}') return result;
                if (c != ',') throw error("Expected comma");
            }
        }
        if (c == '[') {
            List<Object> result = new ArrayList<>();
            space();
            if (pos < text.length() && text.charAt(pos) == ']') { pos++; return result; }
            while (true) {
                result.add(value());
                space();
                c = next();
                if (c == ']') return result;
                if (c != ',') throw error("Expected comma");
            }
        }
        int start = --pos;
        while (pos < text.length() && ",]} \t\r\n".indexOf(text.charAt(pos)) < 0) pos++;
        String token = text.substring(start, pos);
        if (token.equals("true")) return Boolean.TRUE;
        if (token.equals("false")) return Boolean.FALSE;
        if (token.equals("null")) return null;
        if (!token.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?"))
            throw error("Invalid value");
        return new BigDecimal(token);
    }

    private String readString() {
        StringBuilder out = new StringBuilder();
        while (true) {
            char c = next();
            if (c == '"') return out.toString();
            if (c < 32) throw error("Control character in string");
            if (c != '\\') { out.append(c); continue; }
            switch (next()) {
                case '"': out.append('"'); break;
                case '\\': out.append('\\'); break;
                case '/': out.append('/'); break;
                case 'b': out.append('\b'); break;
                case 'f': out.append('\f'); break;
                case 'n': out.append('\n'); break;
                case 'r': out.append('\r'); break;
                case 't': out.append('\t'); break;
                case 'u':
                    if (pos + 4 > text.length()) throw error("Truncated Unicode escape");
                    String hex = text.substring(pos, pos + 4);
                    if (!hex.matches("[0-9a-fA-F]{4}")) throw error("Invalid Unicode escape");
                    out.append((char)Integer.parseInt(hex, 16));
                    pos += 4;
                    break;
                default: throw error("Invalid string escape");
            }
        }
    }
}
