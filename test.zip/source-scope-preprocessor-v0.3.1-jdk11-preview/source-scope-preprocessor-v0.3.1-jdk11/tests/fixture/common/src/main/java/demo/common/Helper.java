package demo.common;
public class Helper { public String hello(){return "hello";} }
class PackageHelper {}
