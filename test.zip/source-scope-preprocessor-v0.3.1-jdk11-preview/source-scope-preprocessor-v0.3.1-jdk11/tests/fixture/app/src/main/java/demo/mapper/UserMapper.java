package demo.mapper;
public interface UserMapper { String find(int id); }
