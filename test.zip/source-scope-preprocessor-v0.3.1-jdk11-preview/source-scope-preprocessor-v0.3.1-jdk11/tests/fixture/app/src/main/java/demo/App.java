package demo;
import demo.common.Helper;
import demo.mapper.UserMapper;
public class App {
 private final Helper helper=new Helper();
 private UserMapper mapper;
 public String message(){return helper.hello();}
}
