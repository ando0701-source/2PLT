@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
set "JAVA_EXE=java"
set "JAVAC_EXE=javac"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" (
 set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
 set "JAVAC_EXE=%JAVA_HOME%\bin\javac.exe"
)
"%JAVAC_EXE%" -version >nul 2>&1
if errorlevel 1 (echo [STOP] JDK 11 or newer is needed.& pause & exit /b 1)
"%JAVA_EXE%" --add-modules jdk.compiler -jar "%~dp0bin\source-scope.jar" check
if errorlevel 1 (echo [FAIL] JDK 11 with jdk.compiler is required.& pause & exit /b 1)
set "TESTROOT=%TEMP%\source-scope-check-%RANDOM%-%RANDOM%"
mkdir "%TESTROOT%"
echo Checking the bundled sample project...
"%JAVA_EXE%" --add-modules jdk.compiler -jar "%~dp0bin\source-scope.jar" analyze --root "%~dp0tests\fixture" --out "%TESTROOT%\result" --all --release 11 --encoding UTF-8
if errorlevel 1 (echo [FAIL] Analysis failed.& pause & exit /b 1)
if not exist "%TESTROOT%\result\lookup\demo\App.json" (echo [FAIL] FQCN lookup file is missing.& pause & exit /b 1)
if not exist "%TESTROOT%\result\run-report.json" (echo [FAIL] Completion report is missing.& pause & exit /b 1)
echo [PASS] Sample analysis finished and expected files were generated.
echo Temporary output: "%TESTROOT%\result"
pause
