#!/bin/sh
set -eu
KIT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
mkdir -p "$KIT/build/classes" "$KIT/bin"
javac --release 11 -encoding UTF-8 -d "$KIT/build/classes" "$KIT"/src/main/java/sourcescope/*.java
jar --create --file "$KIT/bin/source-scope.jar" --main-class sourcescope.Main -C "$KIT/build/classes" .
echo "Built: $KIT/bin/source-scope.jar"
