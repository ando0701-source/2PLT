#!/bin/sh
set -eu
if [ "$#" -lt 2 ]; then
  echo "Usage: sh scripts/analyze.sh /absolute/project/folder /absolute/new-output-folder [JAVA_RELEASE] [ENCODING]" >&2
  exit 2
fi
KIT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
exec java --add-modules jdk.compiler -Xmx4g -jar "$KIT/bin/source-scope.jar" analyze --root "$1" --out "$2" --all --release "${3:-11}" --encoding "${4:-UTF-8}"
