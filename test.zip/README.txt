Source Scope v0.3.5 - one-time recovery helper for final folder rename failure

This helper is not a replacement for the Source Scope application.
Only run it when:
- the old run ended with an error renaming run-XXXXX.building -> run-XXXXX;
- the .building folder still exists;
- the original analysis process is no longer running.

Instructions:
1. Close Explorer, Excel, and editors that have files open in the result folder.
2. Double-click 04_結果を復旧する.bat.
3. Paste the full path ending in .building, press Enter.
4. The tool checks RUN_COMPLETE in execution.log, finalization error marker,
   JSON counts for both layers, and required files.
5. If checks pass, type YES to rename the folder and mark the saved report
   state COMPLETE, with a permanent note of the recovery.

Important:
- If the checks fail, the tool will not rename the folder or mark it complete.
- The original run-report.json is backed up as run-report.before-recovery.json.
- The metrics originally present in the successful run-report.json cannot
  be reconstructed from the overwritten FAILED report. The recovery report
  records that caveat explicitly.
- This is a static review of the PowerShell script. Windows execution has
  NOT been tested in this environment.
- Do not use this tool to bypass errors from the Java / POM / Mapper analysis.
